# CBDR Trading System

Minimal, mathematically grounded CBDR trading bot.
Three components. One tunable parameter. No overfitting.

```
cbdr_trader/
├── main.py                  ← entry point (run this)
├── config.py                ← ALL settings live here
├── requirements.txt
├── core/
│   ├── kalman.py            ← Kalman filter (Kálmán 1960)
│   ├── atr_gate.py          ← ATR volatility gate (Wilder 1978)
│   ├── kelly.py             ← Kelly criterion (Kelly 1956)
│   └── cbdr.py              ← Session state machine
├── data/
│   └── feed.py              ← MT5 data feed
├── backtest/
│   └── walk_forward.py      ← Walk-forward validation
├── execution/
│   └── broker.py            ← MT5 order execution
├── utils/
│   └── logger.py            ← Logging setup
└── logs/                    ← Created automatically
    ├── cbdr_live.log
    ├── trade_history.csv
    └── kelly_state.json      ← Kelly state persists across restarts
```

---

## Prerequisites

- Python 3.11+
- MetaTrader 5 (Windows) with a broker account connected
- The symbol configured in `config.py` available in your terminal

```bash
pip install -r requirements.txt
```

---

## Step 1 — Configure

Edit `config.py`. The only values you should change:

| Setting | Default | Notes |
|---|---|---|
| `SYMBOL` | `"EURUSD"` | Must match your broker's exact symbol string |
| `KALMAN_R_OVER_Q` | `10.0` | The ONE tunable parameter — only adjust after backtest |
| `KELLY_FALLBACK_RISK` | `0.005` | 0.5% risk per trade until 20 trades of history |
| `KELLY_MAX_RISK_CAP` | `0.02` | Hard cap — never exceed this regardless of Kelly |

Everything else is either a literature-grounded constant or derived from your live trade history.

---

## Step 2 — Backtest

Always run the backtest before going live. This validates the system
on your specific broker's data and your chosen symbol.

```bash
python main.py --mode backtest --years 4
```

This runs a 6M-train / 1M-test anchored walk-forward over 4 years of
5-minute EURUSD data. Results print to console and save to `results/`.

**Reading the report:**

| Metric | What to look for |
|---|---|
| `win_rate` | Consistency across folds — look for 0.50–0.65 |
| `avg_r` | Positive in most folds |
| `max_dd_pct` | Should stay < 0.05 (5%) per fold |
| `profit_factor` | > 1.2 is meaningful edge |
| `sharpe` | > 0.5 indicates risk-adjusted consistency |

If results look weak, adjust `KALMAN_R_OVER_Q` — try 5, 8, 12, 15 —
and re-run. Pick the value that performs best on the **test** folds,
not the train folds. That is your live parameter.

---

## Step 3 — Live trading

```bash
python main.py --mode live
```

The bot will:
1. Connect to MT5 and validate the symbol
2. Load persisted Kelly state (or start fresh)
3. Wait for the CBDR window (2–8 PM NY) each day
4. Filter sessions using the ATR gate
5. Watch for the Judas sweep and MSS confirmation
6. Enter at the FVG with Kelly-sized lots
7. Manage partial closes at TP1 (40%), TP2 (35%), TP3 (25%)
8. Halt automatically if daily (2%) or weekly (4%) drawdown is hit
9. Save Kelly state after every trade close

Stop the bot cleanly with Ctrl+C. Kelly state is saved on shutdown.

---

## Monitoring

Live log: `logs/cbdr_live.log`  
Trade log: `logs/trade_history.csv`  
Kelly state: `logs/kelly_state.json`

For debug output (every 5-min candle):
```bash
python main.py --mode live --log-level DEBUG
```

---

## The mathematics

| Component | Basis | Free parameters |
|---|---|---|
| Kalman filter | Kálmán (1960) — optimal linear estimator | **1** — R/Q ratio |
| ATR gate | Wilder (1978) — thresholds from breakout literature | **0** — fixed constants |
| Kelly sizing | Kelly (1956) — maximises geometric growth rate | **0** — derived from your trade history |

Total tunable parameters: **1**. 
There is no meaningful way to overfit a single ratio on a dataset of reasonable size.
