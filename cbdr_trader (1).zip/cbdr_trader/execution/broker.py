"""
execution/broker.py

MetaTrader 5 order execution layer.

Handles:
  - Opening market orders (long / short)
  - Partial position closes at TP1, TP2, TP3
  - Hard stop loss management
  - Daily/weekly drawdown circuit breakers
  - Trade logging to CSV

Separation principle:
  This module knows NOTHING about CBDR logic. It only executes
  what the session state machine tells it to. Signal and execution
  are strictly decoupled.
"""

import logging
import csv
from datetime import datetime, timezone, timedelta
from pathlib  import Path
from typing   import Optional

try:
    import MetaTrader5 as mt5
    MT5_AVAILABLE = True
except ImportError:
    MT5_AVAILABLE = False
    mt5 = None

from config import (
    SYMBOL, MAX_DAILY_DRAWDOWN_PCT, MAX_WEEKLY_DRAWDOWN_PCT,
    MAX_OPEN_TRADES, TP1_CLOSE_PCT, TP2_CLOSE_PCT, TP3_CLOSE_PCT,
    TRADE_LOG_CSV
)

log = logging.getLogger("broker")


class MT5Broker:
    """
    Thin execution wrapper over MetaTrader 5.

    Tracks equity watermarks for drawdown circuit breakers.
    Logs every fill to CSV for Kelly tracker persistence.
    """

    def __init__(self, symbol: str = SYMBOL):
        self.symbol      = symbol
        self._ticket     = None      # current open ticket
        self._open_lots  = 0.0
        self._tp1_done   = False
        self._tp2_done   = False
        self._entry_time = None

        self._day_start_equity   = None
        self._week_start_equity  = None
        self._halted             = False

        Path(TRADE_LOG_CSV).parent.mkdir(parents=True, exist_ok=True)
        self._init_log()

    # ── connection guard ──────────────────────────────────────────────────────

    def _guard(self) -> bool:
        if not MT5_AVAILABLE:
            log.error("MT5 not available.")
            return False
        if self._halted:
            log.warning("Broker HALTED — drawdown limit reached.")
            return False
        return True

    # ── equity snapshots ──────────────────────────────────────────────────────

    def snapshot_day_start(self, equity: float):
        self._day_start_equity = equity

    def snapshot_week_start(self, equity: float):
        self._week_start_equity = equity

    def check_drawdown(self, current_equity: float) -> bool:
        """
        Check daily and weekly drawdown limits.
        Returns True if trading is still permitted.
        Halts the broker if a limit is breached.
        """
        if self._day_start_equity and self._day_start_equity > 0:
            dd_daily = (self._day_start_equity - current_equity) / self._day_start_equity
            if dd_daily >= MAX_DAILY_DRAWDOWN_PCT:
                self._halted = True
                log.critical(
                    f"DAILY DRAWDOWN LIMIT HIT: {dd_daily:.2%} "
                    f"(limit {MAX_DAILY_DRAWDOWN_PCT:.2%}). Trading halted."
                )
                return False

        if self._week_start_equity and self._week_start_equity > 0:
            dd_weekly = (self._week_start_equity - current_equity) / self._week_start_equity
            if dd_weekly >= MAX_WEEKLY_DRAWDOWN_PCT:
                self._halted = True
                log.critical(
                    f"WEEKLY DRAWDOWN LIMIT HIT: {dd_weekly:.2%} "
                    f"(limit {MAX_WEEKLY_DRAWDOWN_PCT:.2%}). Trading halted."
                )
                return False

        return True

    def reset_daily(self, equity: float):
        """Call at session start each day."""
        self._day_start_equity = equity
        self._halted = False   # reset daily halt (weekly halt persists)
        log.info(f"Day reset — equity: {equity:.2f}")

    def reset_weekly(self, equity: float):
        self._week_start_equity = equity
        self._halted = False
        log.info(f"Week reset — equity: {equity:.2f}")

    @property
    def is_halted(self) -> bool:
        return self._halted

    @property
    def has_open_position(self) -> bool:
        return self._ticket is not None

    # ── order execution ───────────────────────────────────────────────────────

    def open_long(self, lots: float, sl: float, tp1: float,
                  tp2: float, tp3: float, comment: str = "CBDR") -> bool:
        if not self._guard():
            return False
        if self.has_open_position:
            log.warning("Cannot open long — position already open.")
            return False
        return self._send_order(
            mt5.ORDER_TYPE_BUY, lots, sl, tp1, tp2, tp3, comment
        )

    def open_short(self, lots: float, sl: float, tp1: float,
                   tp2: float, tp3: float, comment: str = "CBDR") -> bool:
        if not self._guard():
            return False
        if self.has_open_position:
            log.warning("Cannot open short — position already open.")
            return False
        return self._send_order(
            mt5.ORDER_TYPE_SELL, lots, sl, tp1, tp2, tp3, comment
        )

    def _send_order(self, order_type: int, lots: float,
                    sl: float, tp: float,
                    tp2: float, tp3: float,
                    comment: str) -> bool:
        tick = mt5.symbol_info_tick(self.symbol)
        if tick is None:
            log.error("Cannot fetch tick — order aborted.")
            return False

        info = mt5.symbol_info(self.symbol)
        price = tick.ask if order_type == mt5.ORDER_TYPE_BUY else tick.bid
        digits = info.digits

        request = {
            "action":    mt5.TRADE_ACTION_DEAL,
            "symbol":    self.symbol,
            "volume":    lots,
            "type":      order_type,
            "price":     round(price, digits),
            "sl":        round(sl,    digits),
            "tp":        round(tp,    digits),  # TP1 as the MT5 take profit
            "deviation": 20,
            "magic":     20240101,
            "comment":   comment,
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }

        result = mt5.order_send(request)
        if result is None or result.retcode != mt5.TRADE_RETCODE_DONE:
            log.error(
                f"Order failed: {result.retcode if result else 'None'} "
                f"{''+result.comment if result else ''}"
            )
            return False

        self._ticket     = result.order
        self._open_lots  = lots
        self._tp1_done   = False
        self._tp2_done   = False
        self._entry_time = datetime.now(timezone.utc)
        self._tp2_level  = tp2
        self._tp3_level  = tp3
        self._sl_level   = sl
        self._order_type = order_type

        log.info(
            f"Order filled — Ticket:{self._ticket} "
            f"{'BUY' if order_type == mt5.ORDER_TYPE_BUY else 'SELL'} "
            f"{lots}L @ {price:.5f} | SL:{sl:.5f} TP1:{tp:.5f}"
        )
        self._log_trade_open(order_type, lots, price, sl, tp, tp2, tp3)
        return True

    # ── partial closes ────────────────────────────────────────────────────────

    def close_partial(self, close_pct: float, reason: str = "") -> bool:
        """
        Close a percentage of the open position.
        MT5 requires closing into the market at current price.
        """
        if not self._guard():
            return False
        if not self.has_open_position:
            return False

        lots_to_close = round(self._open_lots * close_pct, 2)
        if lots_to_close < 0.01:
            lots_to_close = 0.01

        tick = mt5.symbol_info_tick(self.symbol)
        price = tick.bid if self._order_type == mt5.ORDER_TYPE_BUY else tick.ask

        close_type = (mt5.ORDER_TYPE_SELL
                      if self._order_type == mt5.ORDER_TYPE_BUY
                      else mt5.ORDER_TYPE_BUY)

        request = {
            "action":   mt5.TRADE_ACTION_DEAL,
            "symbol":   self.symbol,
            "volume":   lots_to_close,
            "type":     close_type,
            "position": self._ticket,
            "price":    price,
            "deviation": 20,
            "magic":    20240101,
            "comment":  f"CBDR_{reason}",
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }

        result = mt5.order_send(request)
        if result is None or result.retcode != mt5.TRADE_RETCODE_DONE:
            log.error(f"Partial close failed: {result.retcode if result else 'None'}")
            return False

        self._open_lots -= lots_to_close
        log.info(f"Partial close {close_pct:.0%} — {reason} @ {price:.5f} | "
                 f"Remaining: {self._open_lots:.2f}L")
        self._log_trade_partial(reason, lots_to_close, price)

        if self._open_lots < 0.01:
            self._ticket = None
        return True

    def close_all(self, reason: str = "SL") -> bool:
        """Close entire remaining position."""
        return self.close_partial(1.0, reason=reason)

    # ── action dispatcher ─────────────────────────────────────────────────────

    def execute_action(self, action: dict, equity: float) -> bool:
        """
        Called by the main loop with action dicts from CBDRSession.

        Parameters
        ----------
        action : dict from CBDRSession.on_candle()
        equity : current account equity (for drawdown checks)
        """
        if not self.check_drawdown(equity):
            return False

        act = action.get('action', '')

        if act == 'open_long':
            return self.open_long(
                lots=action['lots'],
                sl=action['sl'],
                tp1=action['tp1'],
                tp2=action['tp2'],
                tp3=action['tp3'],
            )

        if act == 'open_short':
            return self.open_short(
                lots=action['lots'],
                sl=action['sl'],
                tp1=action['tp1'],
                tp2=action['tp2'],
                tp3=action['tp3'],
            )

        if act == 'close_tp1' and not self._tp1_done:
            self._tp1_done = True
            return self.close_partial(TP1_CLOSE_PCT, reason="TP1")

        if act == 'close_tp2' and not self._tp2_done:
            self._tp2_done = True
            return self.close_partial(TP2_CLOSE_PCT, reason="TP2")

        if act == 'close_tp3':
            return self.close_all(reason="TP3")

        if act == 'close_sl':
            return self.close_all(reason="SL")

        if act == 'session_skip':
            log.info(f"Session skipped: {action.get('reason','')}")
            return True

        return False

    # ── trade logging ─────────────────────────────────────────────────────────

    def _init_log(self):
        p = Path(TRADE_LOG_CSV)
        if not p.exists():
            with open(p, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'event', 'symbol', 'direction',
                    'lots', 'price', 'sl', 'tp1', 'tp2', 'tp3', 'ticket'
                ])

    def _log_trade_open(self, order_type, lots, price, sl, tp1, tp2, tp3):
        self._write_log('OPEN',
                        'BUY' if order_type == mt5.ORDER_TYPE_BUY else 'SELL',
                        lots, price, sl, tp1, tp2, tp3)

    def _log_trade_partial(self, reason, lots, price):
        self._write_log(reason, '', lots, price, 0, 0, 0, 0)

    def _write_log(self, event, direction, lots, price, sl, tp1, tp2, tp3):
        with open(TRADE_LOG_CSV, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                datetime.now(timezone.utc).isoformat(),
                event, self.symbol, direction,
                lots, price, sl, tp1, tp2, tp3,
                self._ticket or ''
            ])
