"""
config.py — Single source of truth for all system parameters.
v2: Fixed midnight hour handling, adjusted walk-forward windows for
    brokers that only provide 12-18 months of M5 history.
"""

# ─────────────────────────────────────────────────────────────────────────────
# Broker / instrument
# ─────────────────────────────────────────────────────────────────────────────
SYMBOL          = "EURUSD"
TIMEFRAME_M5    = 5
TIMEFRAME_H1    = 60
BROKER_TIMEZONE = "Etc/UTC"
NY_TIMEZONE     = "America/New_York"


# ─────────────────────────────────────────────────────────────────────────────
# Session windows  (NY time)
#
# IMPORTANT — midnight handling:
#   JUDAS_END_HOUR = 0  means "when ny_hour == 0 AND we are past 8 PM"
#   We track this with a crosses_midnight flag in the state machine.
#   Do NOT use 24 here — Python hour values are always 0-23.
# ─────────────────────────────────────────────────────────────────────────────
CBDR_START_HOUR  = 14   # 2 PM  NY — CBDR formation starts
CBDR_END_HOUR    = 20   # 8 PM  NY — CBDR formation ends
JUDAS_END_HOUR   = 23   # 11 PM NY — latest the Judas sweep must appear
ENTRY_END_HOUR   = 5    # 5 AM  NY — last valid FVG entry
NO_TRADE_DAYS    = [4]  # 4 = Friday (0=Monday). Saturday/Sunday auto-excluded.


# ─────────────────────────────────────────────────────────────────────────────
# Kalman filter — ONE meaningful parameter
# ─────────────────────────────────────────────────────────────────────────────
KALMAN_R_OVER_Q = 10.0


# ─────────────────────────────────────────────────────────────────────────────
# ATR volatility gate — literature-grounded, do not curve-fit
# ─────────────────────────────────────────────────────────────────────────────
ATR_PERIOD          = 14
ATR_ROLLING_AVG     = 20
ATR_LOW_THRESH      = 0.7
ATR_HIGH_THRESH     = 1.8
JUDAS_MIN_ATR_FRAC  = 0.25


# ─────────────────────────────────────────────────────────────────────────────
# Kelly criterion — zero tunable parameters
# ─────────────────────────────────────────────────────────────────────────────
KELLY_FRACTION      = "half"
KELLY_MIN_TRADES    = 20
KELLY_FALLBACK_RISK = 0.005
KELLY_MAX_RISK_CAP  = 0.02

PIP_VALUE_PER_LOT   = 10.0    # USD per pip per standard lot (EURUSD)
SL_BUFFER_PIPS      = 2.0     # pips beyond Judas Low for stop placement


# ─────────────────────────────────────────────────────────────────────────────
# Take profit — partial close percentages
# ─────────────────────────────────────────────────────────────────────────────
TP1_CLOSE_PCT = 0.40
TP2_CLOSE_PCT = 0.35
TP3_CLOSE_PCT = 0.25


# ─────────────────────────────────────────────────────────────────────────────
# Walk-forward settings
#
# Tuned for brokers providing 12-18 months of M5 history.
# If you have 3+ years of data, set TRAIN=6, TEST=1.
# ─────────────────────────────────────────────────────────────────────────────
WF_TRAIN_MONTHS = 3     # training window (months)
WF_TEST_MONTHS  = 1     # out-of-sample test window (months)
WF_MIN_TRADES   = 5     # minimum trades per test fold to include it


# ─────────────────────────────────────────────────────────────────────────────
# Live risk controls
# ─────────────────────────────────────────────────────────────────────────────
MAX_DAILY_DRAWDOWN_PCT  = 0.02
MAX_WEEKLY_DRAWDOWN_PCT = 0.04
MAX_OPEN_TRADES         = 1


# ─────────────────────────────────────────────────────────────────────────────
# Paths
# ─────────────────────────────────────────────────────────────────────────────
LOG_FILE      = "logs/cbdr_live.log"
TRADE_LOG_CSV = "logs/trade_history.csv"
RESULTS_DIR   = "results/"
