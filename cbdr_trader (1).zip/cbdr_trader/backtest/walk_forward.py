"""
backtest/walk_forward.py  --  v4

Fix: open trades now carry over across NY calendar day boundaries.
Previously a trade opened at 4 AM NY would not close if TP/SL
wasn't hit before midnight NY — the next day's session loop started
fresh and the trade was silently abandoned. Now the trade stays
active until it closes, regardless of day boundary.
"""

import logging
import warnings
import math
from datetime import datetime
from pathlib import Path
from dateutil.relativedelta import relativedelta

import numpy as np
import pandas as pd

from core.kalman    import KalmanLevel
from core.atr_gate  import ATRVolatilityGate
from core.kelly     import KellyTracker
from core.cbdr      import CBDRSession, SessionState
from config import (
    WF_TRAIN_MONTHS, WF_TEST_MONTHS, WF_MIN_TRADES,
    KALMAN_R_OVER_Q, NO_TRADE_DAYS, RESULTS_DIR, NY_TIMEZONE
)
from zoneinfo import ZoneInfo

log = logging.getLogger("backtest")
warnings.filterwarnings('ignore', category=FutureWarning)


# ─────────────────────────────────────────────────────────────────────────────
# Signal generation
# ─────────────────────────────────────────────────────────────────────────────

def generate_signals(df: pd.DataFrame,
                     kalman_rq: float = KALMAN_R_OVER_Q,
                     initial_equity: float = 10_000.0,
                     verbose: bool = False) -> tuple[pd.DataFrame, dict]:
    """
    Simulate CBDR logic bar-by-bar, grouped by NY calendar date.

    Open trades carry over midnight — a trade entered at 4 AM NY
    continues to be managed on subsequent bars until TP/SL is hit.
    """
    if df.empty:
        return pd.DataFrame(), _empty_stats()

    kelly  = KellyTracker()
    equity = initial_equity
    trades = []
    stats  = _empty_stats()

    ny_tz    = ZoneInfo(NY_TIMEZONE)
    ny_index = df.index.tz_convert(ny_tz)
    df       = df.copy()
    df['_ny_date'] = ny_index.normalize()
    df['_ny_hour'] = ny_index.hour
    df['_dow']     = ny_index.dayofweek

    # ── Carry-over state ─────────────────────────────────────────────────────
    # When a trade is open at end of day, we store it here and continue
    # managing it on the next day's candles before starting a new session.
    carry_open_trade: dict | None = None   # action dict from open_long/short
    carry_entry_time = None
    carry_setup      = None                # TradeSetup snapshot for P&L calc

    for ny_date, day_df in df.groupby('_ny_date'):
        if day_df.empty:
            continue

        dow = int(day_df['_dow'].iloc[0])

        # ── If we have a carry-over trade, manage it first ────────────────
        if carry_open_trade is not None:
            for ts, row in day_df.iterrows():
                candle = _row_to_candle(ts, row)
                closed = _check_close(candle, carry_open_trade)
                if closed:
                    pnl_r    = closed['pnl_r']
                    is_win   = closed['is_win']
                    risk_usd = carry_open_trade['lots'] * carry_open_trade['sl_pips'] * 10.0
                    pnl_usd  = pnl_r * risk_usd
                    equity   = max(equity + pnl_usd, 1.0)
                    kelly.log_trade(abs(pnl_r), is_win)

                    trades.append({
                        'entry_time': carry_entry_time,
                        'exit_time':  ts,
                        'direction':  carry_open_trade['action'].replace('open_', ''),
                        'entry':      carry_open_trade['entry'],
                        'exit_price': closed['price'],
                        'sl':         carry_open_trade['sl'],
                        'tp1':        carry_open_trade['tp1'],
                        'tp2':        carry_open_trade['tp2'],
                        'lots':       carry_open_trade['lots'],
                        'sl_pips':    carry_open_trade['sl_pips'],
                        'pnl_r':      pnl_r,
                        'pnl_dollar': pnl_usd,
                        'is_win':     is_win,
                        'close_type': closed['action'],
                        'equity':     equity,
                        'carried':    True,
                    })
                    carry_open_trade = None
                    carry_entry_time = None
                    break   # trade closed — rest of this day is a new session

            if carry_open_trade is not None:
                # Trade still open at end of day — carry to tomorrow
                continue

        # ── Skip no-trade days AFTER carry-over is resolved ───────────────
        if dow in NO_TRADE_DAYS or dow >= 5:
            stats["skip_dow"] += 1
            continue

        # ── Normal session ─────────────────────────────────────────────────
        stats["sessions"] += 1
        session    = CBDRSession(kelly, equity, kalman_rq=kalman_rq)
        entry_time = None
        open_trade = None

        week_start = ny_date - pd.Timedelta(days=7)
        week_data  = df[df['_ny_date'] >= week_start]
        if not week_data.empty:
            session.set_weekly_levels(
                week_data['high'].max(),
                week_data['low'].min()
            )

        for ts, row in day_df.iterrows():
            candle  = _row_to_candle(ts, row)
            ny_hour = int(row['_ny_hour'])

            atr_now = row['atr_14']
            atr_avg = row['atr_20avg']
            if math.isnan(atr_now): atr_now = 0.001
            if math.isnan(atr_avg): atr_avg = 0.001

            action = session.on_candle(candle, atr_now, atr_avg, ny_hour)
            if action is None:
                continue

            act = action['action']

            if act == 'session_skip':
                reason = action.get('reason', '')
                stats["skipped"] += 1
                if   'No CBDR'  in reason: stats["skip_no_cbdr"]  += 1
                elif 'ATR'      in reason: stats["skip_atr_gate"] += 1
                elif 'Judas'    in reason: stats["skip_no_judas"] += 1
                elif 'expired'  in reason or 'Entry' in reason:
                    stats["skip_no_entry"] += 1
                break

            if act in ('open_long', 'open_short'):
                entry_time = ts
                open_trade = action
                stats["traded"] += 1

            elif act in ('close_tp1', 'close_tp2', 'close_tp3', 'close_sl'):
                if open_trade is None:
                    continue
                pnl_r    = action.get('pnl_r', 0.0)
                is_win   = action.get('is_win', False)
                risk_usd = open_trade['lots'] * open_trade['sl_pips'] * 10.0
                pnl_usd  = pnl_r * risk_usd
                equity   = max(equity + pnl_usd, 1.0)

                trades.append({
                    'entry_time': entry_time,
                    'exit_time':  ts,
                    'direction':  open_trade['action'].replace('open_', ''),
                    'entry':      open_trade['entry'],
                    'exit_price': action['price'],
                    'sl':         open_trade['sl'],
                    'tp1':        open_trade['tp1'],
                    'tp2':        open_trade['tp2'],
                    'lots':       open_trade['lots'],
                    'sl_pips':    open_trade['sl_pips'],
                    'pnl_r':      pnl_r,
                    'pnl_dollar': pnl_usd,
                    'is_win':     is_win,
                    'close_type': act,
                    'equity':     equity,
                    'carried':    False,
                })
                open_trade = None

        # ── End of day: carry open trade if not yet closed ────────────────
        if open_trade is not None:
            carry_open_trade = open_trade
            carry_entry_time = entry_time
            log.debug(f"Trade carried over from {ny_date.date()}")

        if verbose:
            log.info(f"  {ny_date.date()} dow={dow} "
                     f"state={session.state.name}")

    # ── Any trade still open at end of dataset: record as open ────────────
    # (In a real backtest this would be forced-closed at last price.
    #  We simply drop it — it's at most 1 trade.)
    if carry_open_trade is not None:
        log.debug("Dataset ended with one trade still open — excluded from results.")

    return pd.DataFrame(trades), stats


def _row_to_candle(ts, row) -> dict:
    return {
        'time':   ts,
        'open':   row['open'],
        'high':   row['high'],
        'low':    row['low'],
        'close':  row['close'],
        'volume': row.get('volume', 0),
    }


def _check_close(candle: dict, open_trade: dict) -> dict | None:
    """
    Check if a carry-over open trade hits TP or SL on this candle.
    Returns a close dict or None.
    """
    act    = open_trade['action']
    entry  = open_trade['entry']
    sl     = open_trade['sl']
    tp1    = open_trade['tp1']
    tp2    = open_trade['tp2']
    tp3    = open_trade['tp3']
    is_long = act == 'open_long'

    def close(label, price):
        if is_long:
            pnl_r = (price - entry) / (entry - sl) if entry != sl else 0
        else:
            pnl_r = (entry - price) / (sl - entry) if sl != entry else 0
        return {
            'action': label,
            'price':  price,
            'pnl_r':  round(pnl_r, 3),
            'is_win': label != 'close_sl',
        }

    if is_long:
        if candle['low']  <= sl:  return close('close_sl',  sl)
        if candle['high'] >= tp3: return close('close_tp3', tp3)
        if candle['high'] >= tp2: return close('close_tp2', tp2)
        if candle['high'] >= tp1: return close('close_tp1', tp1)
    else:
        if candle['high'] >= sl:  return close('close_sl',  sl)
        if candle['low']  <= tp3: return close('close_tp3', tp3)
        if candle['low']  <= tp2: return close('close_tp2', tp2)
        if candle['low']  <= tp1: return close('close_tp1', tp1)
    return None


def _empty_stats() -> dict:
    return {
        "sessions": 0, "skipped": 0, "traded": 0,
        "skip_no_cbdr": 0, "skip_atr_gate": 0,
        "skip_no_judas": 0, "skip_no_entry": 0, "skip_dow": 0,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Walk-forward engine
# ─────────────────────────────────────────────────────────────────────────────

class WalkForwardBacktest:
    def __init__(self,
                 df:             pd.DataFrame,
                 train_months:   int   = WF_TRAIN_MONTHS,
                 test_months:    int   = WF_TEST_MONTHS,
                 min_trades:     int   = WF_MIN_TRADES,
                 initial_equity: float = 10_000.0,
                 kalman_rq:      float = KALMAN_R_OVER_Q):
        self.df           = df
        self.train_months = train_months
        self.test_months  = test_months
        self.min_trades   = min_trades
        self.equity       = initial_equity
        self.kalman_rq    = kalman_rq
        self.fold_results = []
        self.all_trades   = []
        self.all_stats    = []

    def run(self) -> "WalkForwardBacktest":
        idx        = self.df.index
        start      = idx.min().normalize()
        end        = idx.max().normalize()
        fold_start = start
        fold_num   = 0

        while True:
            train_end = fold_start + relativedelta(months=self.train_months)
            test_end  = train_end  + relativedelta(months=self.test_months)
            if test_end > end:
                break

            fold_num += 1
            train_df = self.df[(self.df.index >= fold_start) & (self.df.index < train_end)]
            test_df  = self.df[(self.df.index >= train_end)  & (self.df.index < test_end)]

            if train_df.empty or test_df.empty:
                fold_start += relativedelta(months=self.test_months)
                continue

            log.info(
                f"Fold {fold_num}: "
                f"train {fold_start.date()}→{train_end.date()} | "
                f"test  {train_end.date()}→{test_end.date()}"
            )

            generate_signals(train_df, self.kalman_rq, self.equity)
            test_trades, test_stats = generate_signals(
                test_df, self.kalman_rq, self.equity
            )

            self.all_stats.append({
                "fold": fold_num,
                "period": f"{train_end.date()}→{test_end.date()}",
                **test_stats
            })

            log.info(
                f"  sessions:{test_stats['sessions']} "
                f"traded:{test_stats['traded']} "
                f"closed:{len(test_trades)} "
                f"skipped:{test_stats['skipped']} "
                f"(no_cbdr:{test_stats['skip_no_cbdr']} "
                f"atr:{test_stats['skip_atr_gate']})"
            )

            if not test_trades.empty:
                test_trades['fold'] = fold_num
                self.all_trades.append(test_trades)
                self.fold_results.append(
                    self._compute_metrics(test_trades, fold_num)
                )

            fold_start += relativedelta(months=self.test_months)

        log.info(
            f"Walk-forward complete — {fold_num} folds, "
            f"{len(self.fold_results)} with trades."
        )
        return self

    def summary(self) -> pd.DataFrame:
        if not self.fold_results:
            return pd.DataFrame()
        return pd.DataFrame(self.fold_results).set_index('fold')

    def signal_diagnostics(self) -> pd.DataFrame:
        if not self.all_stats:
            return pd.DataFrame()
        return pd.DataFrame(self.all_stats).set_index('fold')

    def aggregate(self) -> dict:
        if not self.all_trades:
            return {}
        return self._compute_metrics(
            pd.concat(self.all_trades, ignore_index=True),
            fold=0, label="AGGREGATE"
        )

    def print_report(self):
        s = self.summary()
        a = self.aggregate()
        d = self.signal_diagnostics()

        print("\n" + "═" * 72)
        print("  CBDR WALK-FORWARD BACKTEST REPORT  (v4 — carry-over fix)")
        print("═" * 72)
        print(f"  Symbol       : {self.df.attrs.get('symbol', 'EURUSD')}")
        print(f"  Data period  : {self.df.index.min().date()} → {self.df.index.max().date()}")
        print(f"  Kalman R/Q   : {self.kalman_rq}")
        print(f"  Windows      : {self.train_months}M train / {self.test_months}M test")
        print(f"  Folds total  : {len(self.all_stats)}")
        print(f"  Folds traded : {len(self.fold_results)}")
        print("─" * 72)

        if not s.empty:
            print("\n  Per-fold performance (OOS only):\n")
            cols = [c for c in ['n_trades','win_rate','avg_r','avg_win_r',
                                 'avg_loss_r','max_dd_pct','profit_factor']
                    if c in s.columns]
            print(s[cols].to_string())

        print("\n" + "─" * 72)
        if a:
            print("  AGGREGATE — all out-of-sample trades:\n")
            skip = {'fold', 'label'}
            for k, v in a.items():
                if k in skip: continue
                val = f"{v:>12.4f}" if isinstance(v, float) else f"{str(v):>12}"
                print(f"    {k:<30} {val}")

            wr  = a.get('win_rate', 0)
            ar  = a.get('avg_r', 0)
            pf  = a.get('profit_factor', 0)
            awr = a.get('avg_win_r', 0)
            alr = a.get('avg_loss_r', 1)
            mdd = abs(a.get('max_dd_pct', 0))
            rr  = awr / alr if alr > 0 else 0

            print("\n  ── Summary ──────────────────────────────────────────")
            print(f"  Win rate      {wr:.1%}")
            print(f"  Avg R/trade   {ar:+.3f}")
            print(f"  R:R           {awr:.2f}W / {alr:.2f}L = {rr:.2f}")
            print(f"  Profit factor {pf:.2f}  {'✓' if pf > 1.2 else '△'}")
            print(f"  Max drawdown  {mdd:.2%}  {'✓ <5%' if mdd < 0.05 else '△ >5% — use quarter-Kelly live'}")

            # Go-live readiness
            print("\n  ── Go-live checklist ───────────────────────────────")
            checks = [
                (pf > 1.2,       f"Profit factor {pf:.2f} > 1.2"),
                (ar > 0,         f"Positive avg R ({ar:+.3f})"),
                (rr > 1.2,       f"R:R ratio {rr:.2f} > 1.2"),
                (mdd < 0.05,     f"Max DD {mdd:.2%} < 5%"),
                (wr > 0.40,      f"Win rate {wr:.1%} > 40%"),
            ]
            all_pass = True
            for ok, label in checks:
                print(f"  {'✓' if ok else '✗'} {label}")
                if not ok: all_pass = False

            print()
            if all_pass:
                print("  VERDICT: Edge confirmed. Paper trade 2–4 weeks,")
                print("  then start live with quarter-Kelly until 20 trades.")
            else:
                print("  VERDICT: Some checks failed. Review failing folds")
                print("  before going live.")

        print("═" * 72 + "\n")

    def save(self, results_dir: str = RESULTS_DIR):
        Path(results_dir).mkdir(parents=True, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.summary().to_csv(Path(results_dir) / f"wf_summary_{ts}.csv")
        if self.all_trades:
            pd.concat(self.all_trades).to_csv(
                Path(results_dir) / f"wf_trades_{ts}.csv", index=False
            )
        log.info(f"Results saved → {results_dir}")

    @staticmethod
    def _compute_metrics(trades: pd.DataFrame,
                         fold: int, label: str = "") -> dict:
        if trades.empty:
            return {'fold': fold, 'label': label}

        wins = trades[trades['is_win']]
        loss = trades[~trades['is_win']]
        wr   = len(wins) / len(trades)
        ar   = trades['pnl_r'].mean()

        eq       = trades['equity']
        roll_max = eq.cummax()
        max_dd   = ((eq - roll_max) / roll_max).min()

        daily = trades.groupby(
            pd.to_datetime(trades['exit_time']).dt.date
        )['pnl_dollar'].sum()
        sharpe = (daily.mean()/daily.std()*np.sqrt(252)
                  if daily.std() > 0 else 0.0)

        gw = wins['pnl_dollar'].sum()  if not wins.empty else 0.0
        gl = loss['pnl_dollar'].abs().sum() if not loss.empty else 1.0
        pf = gw / gl if gl > 0 else float('inf')

        return {
            'fold':          fold,
            'label':         label,
            'n_trades':      len(trades),
            'win_rate':      round(wr, 4),
            'avg_r':         round(ar, 4),
            'avg_win_r':     round(wins['pnl_r'].mean(), 4) if not wins.empty else 0.0,
            'avg_loss_r':    round(loss['pnl_r'].abs().mean(), 4) if not loss.empty else 0.0,
            'max_dd_pct':    round(max_dd, 4),
            'sharpe':        round(sharpe, 4),
            'profit_factor': round(pf, 4),
            'total_pnl_r':   round(trades['pnl_r'].sum(), 4),
        }


def run_backtest(df: pd.DataFrame,
                 kalman_rq: float = KALMAN_R_OVER_Q,
                 save: bool = True) -> WalkForwardBacktest:
    wf = WalkForwardBacktest(df, kalman_rq=kalman_rq)
    wf.run()
    wf.print_report()
    if save:
        wf.save()
    return wf
