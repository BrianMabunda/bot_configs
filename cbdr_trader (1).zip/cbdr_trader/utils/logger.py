"""
utils/logger.py

Structured logging setup.

Configures two handlers:
  1. Console — INFO level, coloured prefix for readability
  2. File    — DEBUG level, full timestamped records

All application modules use logging.getLogger("module_name") —
they never configure their own handlers.
"""

import logging
import sys
from pathlib import Path
from datetime import datetime
from config import LOG_FILE


def setup_logging(level: str = "INFO"):
    """
    Call once at application startup (in main.py).
    After this, all module loggers inherit the root configuration.
    """
    Path(LOG_FILE).parent.mkdir(parents=True, exist_ok=True)

    root = logging.getLogger()
    root.setLevel(logging.DEBUG)   # root accepts everything; handlers filter

    # ── console handler ───────────────────────────────────────────────────────
    console = logging.StreamHandler(sys.stdout)
    console.setLevel(getattr(logging, level.upper(), logging.INFO))
    console.setFormatter(_ColourFormatter())
    root.addHandler(console)

    # ── file handler ──────────────────────────────────────────────────────────
    fh = logging.FileHandler(LOG_FILE, encoding='utf-8')
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)-12s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    ))
    root.addHandler(fh)

    logging.getLogger("cbdr").info(
        f"Logging started — file: {LOG_FILE}"
    )


class _ColourFormatter(logging.Formatter):
    """ANSI colour codes for console log levels."""
    RESET  = "\033[0m"
    CODES  = {
        logging.DEBUG:    "\033[90m",   # dark gray
        logging.INFO:     "\033[0m",    # default
        logging.WARNING:  "\033[33m",   # yellow
        logging.ERROR:    "\033[31m",   # red
        logging.CRITICAL: "\033[1;31m", # bold red
    }

    def format(self, record):
        colour = self.CODES.get(record.levelno, "")
        record.msg = f"{colour}{record.msg}{self.RESET}"
        return super().format(record)

    def __init__(self):
        super().__init__(
            fmt="%(asctime)s %(levelname)-8s [%(name)s] %(message)s",
            datefmt="%H:%M:%S"
        )
