"""
core/cbdr.py  --  v3

State machine fixes:
  1. Entry R:R enforcement — TP1 must be at least MIN_RR × SL distance
     from entry. If CBDR opposite side is too close, we project a
     synthetic TP at the required R multiple.
  2. Midnight crossing — CBDR window detection now uses ny_hour from
     the caller (already correctly computed in v2).
  3. Judas window — uses JUDAS_END_HOUR directly (23), no modulo.
  4. Entry trigger — requires close ABOVE fvg_bot (not just touching
     the mid) to reduce noise entries.
"""

from enum import Enum, auto
from dataclasses import dataclass, field
from typing import Optional
import logging
import math

from core.kalman   import KalmanLevel
from core.atr_gate import ATRVolatilityGate
from core.kelly    import KellyTracker
from config import (
    CBDR_START_HOUR, CBDR_END_HOUR, JUDAS_END_HOUR, ENTRY_END_HOUR,
    SL_BUFFER_PIPS, NY_TIMEZONE
)

log = logging.getLogger("cbdr")

# Minimum acceptable R:R for TP1.
# If the CBDR opposite side gives less than this, we project a synthetic TP.
MIN_TP1_RR = 1.5


class SessionState(Enum):
    WAITING_CBDR  = auto()
    WAITING_JUDAS = auto()
    WAITING_ENTRY = auto()
    IN_TRADE      = auto()
    DONE          = auto()
    HALTED        = auto()


@dataclass
class CBDRLevels:
    high:          float = 0.0
    low:           float = 0.0
    judas_low:     float = float('inf')
    judas_high:    float = 0.0
    fvg_top:       float = 0.0
    fvg_bot:       float = 0.0
    mss_confirmed: bool  = False


@dataclass
class TradeSetup:
    direction:      str   = ""
    entry:          float = 0.0
    sl:             float = 0.0
    tp1:            float = 0.0
    tp2:            float = 0.0
    tp3:            float = 0.0
    lot_size:       float = 0.0
    sl_pips:        float = 0.0
    kelly_fraction: float = 0.0
    rr_at_tp1:      float = 0.0


class CBDRSession:
    """One trading day. Returns action dicts that the broker executes."""

    def __init__(self,
                 kelly:          KellyTracker,
                 account_equity: float,
                 kalman_rq:      float = 10.0):
        self.kelly  = kelly
        self.equity = account_equity
        self.state  = SessionState.WAITING_CBDR

        self.kf_high = KalmanLevel(kalman_rq)
        self.kf_low  = KalmanLevel(kalman_rq)
        self.gate    = ATRVolatilityGate()

        self.levels  = CBDRLevels()
        self.setup   = TradeSetup()

        self._session_high = 0.0
        self._session_low  = float('inf')
        self._weekly_high  = 0.0
        self._weekly_low   = float('inf')
        self._cbdr_built   = False
        self._prev_candle  = None

    # ── public ───────────────────────────────────────────────────────────────

    def on_candle(self, candle, current_atr, avg_atr, ny_hour) -> Optional[dict]:
        if self.state in (SessionState.DONE, SessionState.HALTED):
            return None

        self._session_high = max(self._session_high, candle['high'])
        self._session_low  = min(self._session_low,  candle['low'])

        dispatch = {
            SessionState.WAITING_CBDR:  self._handle_cbdr,
            SessionState.WAITING_JUDAS: self._handle_judas,
            SessionState.WAITING_ENTRY: self._handle_entry,
            SessionState.IN_TRADE:      self._handle_in_trade,
        }
        result = dispatch[self.state](candle, current_atr, avg_atr, ny_hour)
        self._prev_candle = candle
        return result

    def set_weekly_levels(self, high: float, low: float):
        self._weekly_high = high
        self._weekly_low  = low

    def halt(self, reason: str):
        self.state = SessionState.HALTED
        log.warning(f"Session halted: {reason}")

    # ── state handlers ────────────────────────────────────────────────────────

    def _handle_cbdr(self, candle, current_atr, avg_atr, ny_hour):
        # Feed Kalman during CBDR window
        if CBDR_START_HOUR <= ny_hour < CBDR_END_HOUR:
            self.levels.high = self.kf_high.update(candle['high'])
            self.levels.low  = self.kf_low.update(candle['low'])
            return None

        # First candle at or after 8 PM — lock CBDR
        if ny_hour >= CBDR_END_HOUR and not self._cbdr_built:
            self._cbdr_built = True

            if not self.kf_high.is_initialised():
                self.state = SessionState.DONE
                return {"action": "session_skip", "reason": "No CBDR data"}

            atr_ok = True
            if not (math.isnan(avg_atr) or avg_atr <= 0):
                atr_ok, msg = self.gate.session_is_valid(current_atr, avg_atr)
                if not atr_ok:
                    self.state = SessionState.DONE
                    return {"action": "session_skip", "reason": msg}

            log.debug(
                f"CBDR locked H:{self.levels.high:.5f} L:{self.levels.low:.5f}"
            )
            self.state = SessionState.WAITING_JUDAS

        return None

    def _handle_judas(self, candle, current_atr, avg_atr, ny_hour):
        # Window: CBDR_END_HOUR(20) to JUDAS_END_HOUR(23), same calendar day
        if ny_hour > JUDAS_END_HOUR or ny_hour < CBDR_END_HOUR:
            # Also allow the entry window to start naturally
            if ny_hour < ENTRY_END_HOUR:
                # We've crossed midnight without a sweep
                self.state = SessionState.DONE
                return {"action": "session_skip", "reason": "No Judas sweep before midnight"}
            return None

        cbdr_range = self.levels.high - self.levels.low
        if cbdr_range <= 0:
            return None

        if math.isnan(current_atr) or current_atr <= 0:
            min_depth = cbdr_range * 0.15
        else:
            min_depth = self.gate.judas_min * current_atr

        # Bullish: sweep below CBDR Low
        if candle['low'] < self.levels.low:
            depth = self.levels.low - candle['low']
            self.levels.judas_low = min(self.levels.judas_low, candle['low'])
            if depth >= min_depth:
                log.debug(f"Judas LOW: {self.levels.judas_low:.5f} depth:{depth:.5f}")
                self.state = SessionState.WAITING_ENTRY

        # Bearish: sweep above CBDR High
        elif candle['high'] > self.levels.high:
            depth = candle['high'] - self.levels.high
            self.levels.judas_high = max(self.levels.judas_high, candle['high'])
            if depth >= min_depth:
                log.debug(f"Judas HIGH: {self.levels.judas_high:.5f} depth:{depth:.5f}")
                self.state = SessionState.WAITING_ENTRY

        return None

    def _handle_entry(self, candle, current_atr, avg_atr, ny_hour):
        # Entry window: midnight (0) to ENTRY_END_HOUR (5)
        # Also allow late entries during London if ny_hour < ENTRY_END_HOUR
        if ENTRY_END_HOUR <= ny_hour < CBDR_START_HOUR:
            self.state = SessionState.DONE
            return {"action": "session_skip", "reason": "Entry window expired"}

        direction = self._infer_direction()
        if direction == 'none':
            return None

        return (self._check_long(candle, current_atr)
                if direction == 'long'
                else self._check_short(candle, current_atr))

    def _check_long(self, candle, current_atr):
        mss_level = self.levels.low

        if not self.levels.mss_confirmed:
            if candle['close'] > mss_level:
                self.levels.mss_confirmed = True
                prev = self._prev_candle
                self.levels.fvg_bot = prev['high'] if prev else mss_level
                self.levels.fvg_top = candle['high']
                log.debug(
                    f"Long MSS. FVG {self.levels.fvg_bot:.5f}–{self.levels.fvg_top:.5f}"
                )
            return None

        # Entry: price pulls back into FVG and closes inside it
        fvg_bot = self.levels.fvg_bot
        fvg_top = self.levels.fvg_top
        if fvg_bot >= fvg_top:
            return None

        if candle['low'] <= fvg_top and candle['close'] >= fvg_bot:
            return self._build_long(candle, current_atr)

        return None

    def _check_short(self, candle, current_atr):
        mss_level = self.levels.high

        if not self.levels.mss_confirmed:
            if candle['close'] < mss_level:
                self.levels.mss_confirmed = True
                prev = self._prev_candle
                self.levels.fvg_top = prev['low'] if prev else mss_level
                self.levels.fvg_bot = candle['low']
                log.debug(
                    f"Short MSS. FVG {self.levels.fvg_bot:.5f}–{self.levels.fvg_top:.5f}"
                )
            return None

        fvg_bot = self.levels.fvg_bot
        fvg_top = self.levels.fvg_top
        if fvg_bot >= fvg_top:
            return None

        if candle['high'] >= fvg_bot and candle['close'] <= fvg_top:
            return self._build_short(candle, current_atr)

        return None

    def _build_long(self, candle, current_atr) -> dict:
        entry   = candle['close']
        sl      = self.levels.judas_low - (SL_BUFFER_PIPS * 0.0001)
        sl_dist = entry - sl
        if sl_dist <= 0:
            return None

        sl_pips = sl_dist * 10_000

        # ── TP with minimum R:R enforcement ──────────────────────────────────
        cbdr_high = self.levels.high
        natural_rr = (cbdr_high - entry) / sl_dist if sl_dist > 0 else 0

        if natural_rr >= MIN_TP1_RR:
            tp1 = cbdr_high                          # CBDR High gives good R
        else:
            tp1 = entry + MIN_TP1_RR * sl_dist       # project required R

        tp2 = entry + 2.5 * sl_dist                  # 2.5R
        tp3 = entry + 4.0 * sl_dist                  # 4.0R

        rr_tp1 = (tp1 - entry) / sl_dist

        kf   = self.kelly.risk_fraction()
        lots = self.kelly.position_size_lots(self.equity, sl_pips)

        self.setup = TradeSetup(
            direction='long', entry=entry, sl=sl,
            tp1=tp1, tp2=tp2, tp3=tp3,
            lot_size=lots, sl_pips=sl_pips,
            kelly_fraction=kf, rr_at_tp1=rr_tp1
        )
        self.state = SessionState.IN_TRADE

        log.debug(
            f"LONG @ {entry:.5f} SL:{sl:.5f} TP1:{tp1:.5f}({rr_tp1:.1f}R) "
            f"TP2:{tp2:.5f}(2.5R) {lots:.2f}L"
        )
        return {
            "action": "open_long", "entry": entry, "sl": sl,
            "tp1": tp1, "tp2": tp2, "tp3": tp3,
            "lots": lots, "sl_pips": sl_pips,
        }

    def _build_short(self, candle, current_atr) -> dict:
        entry   = candle['close']
        sl      = self.levels.judas_high + (SL_BUFFER_PIPS * 0.0001)
        sl_dist = sl - entry
        if sl_dist <= 0:
            return None

        sl_pips = sl_dist * 10_000

        cbdr_low   = self.levels.low
        natural_rr = (entry - cbdr_low) / sl_dist if sl_dist > 0 else 0

        if natural_rr >= MIN_TP1_RR:
            tp1 = cbdr_low
        else:
            tp1 = entry - MIN_TP1_RR * sl_dist

        tp2 = entry - 2.5 * sl_dist
        tp3 = entry - 4.0 * sl_dist

        rr_tp1 = (entry - tp1) / sl_dist
        kf     = self.kelly.risk_fraction()
        lots   = self.kelly.position_size_lots(self.equity, sl_pips)

        self.setup = TradeSetup(
            direction='short', entry=entry, sl=sl,
            tp1=tp1, tp2=tp2, tp3=tp3,
            lot_size=lots, sl_pips=sl_pips,
            kelly_fraction=kf, rr_at_tp1=rr_tp1
        )
        self.state = SessionState.IN_TRADE

        log.debug(
            f"SHORT @ {entry:.5f} SL:{sl:.5f} TP1:{tp1:.5f}({rr_tp1:.1f}R) "
            f"{lots:.2f}L"
        )
        return {
            "action": "open_short", "entry": entry, "sl": sl,
            "tp1": tp1, "tp2": tp2, "tp3": tp3,
            "lots": lots, "sl_pips": sl_pips,
        }

    def _handle_in_trade(self, candle, current_atr, avg_atr, ny_hour):
        s = self.setup
        if s.direction == 'long':
            if candle['low']  <= s.sl:  return self._close("close_sl",  s.sl)
            if candle['high'] >= s.tp3: return self._close("close_tp3", s.tp3)
            if candle['high'] >= s.tp2: return self._close("close_tp2", s.tp2)
            if candle['high'] >= s.tp1: return self._close("close_tp1", s.tp1)
        else:
            if candle['high'] >= s.sl:  return self._close("close_sl",  s.sl)
            if candle['low']  <= s.tp3: return self._close("close_tp3", s.tp3)
            if candle['low']  <= s.tp2: return self._close("close_tp2", s.tp2)
            if candle['low']  <= s.tp1: return self._close("close_tp1", s.tp1)
        return None

    def _close(self, action: str, price: float) -> dict:
        s      = self.setup
        is_win = action != "close_sl"
        if s.direction == 'long':
            pnl_r = (price - s.entry) / (s.entry - s.sl) if s.entry != s.sl else 0
        else:
            pnl_r = (s.entry - price) / (s.sl - s.entry) if s.sl != s.entry else 0

        self.kelly.log_trade(abs(pnl_r), is_win)
        self.state = SessionState.DONE
        log.debug(f"{action} @ {price:.5f} R:{pnl_r:.2f} | {self.kelly.summary()}")
        return {
            "action": action, "price": price,
            "pnl_r": round(pnl_r, 3), "is_win": is_win, "lots": s.lot_size,
        }

    def _infer_direction(self) -> str:
        swept_low  = self.levels.judas_low  < self.levels.low
        swept_high = self.levels.judas_high > self.levels.high
        if swept_low and not swept_high:  return 'long'
        if swept_high and not swept_low:  return 'short'
        return 'none'
