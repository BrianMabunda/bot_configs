"""
core/atr_gate.py

ATR-based volatility gate for CBDR session validation.

Mathematical basis:
  Average True Range (Wilder, 1978) is a direct measurement of
  recent market activity — not a model, not a forecast.
  The True Range at bar k is:

    TR_k = max(High_k - Low_k,
               |High_k - Close_{k-1}|,
               |Low_k  - Close_{k-1}|)

  ATR is the exponentially weighted mean with alpha = 1/period
  (Wilder smoothing, equivalent to EMA with span = 2*period - 1).

  The gate compares today's ATR to its 20-day rolling mean.
  The thresholds (0.7, 1.8) are taken from published volatility-
  filtered breakout research (Donchian channels, Pring momentum)
  and are NOT optimised on this dataset.
"""

import pandas as pd
import numpy as np
from config import ATR_PERIOD, ATR_ROLLING_AVG, ATR_LOW_THRESH, ATR_HIGH_THRESH, JUDAS_MIN_ATR_FRAC


# ─────────────────────────────────────────────────────────────────────────────
# ATR calculation
# ─────────────────────────────────────────────────────────────────────────────

def compute_atr(df: pd.DataFrame, period: int = ATR_PERIOD) -> pd.Series:
    """
    Wilder ATR on an OHLCV DataFrame.
    Expects columns: 'high', 'low', 'close'.

    Returns a Series of ATR values aligned to df.index.
    """
    high  = df['high']
    low   = df['low']
    prev_close = df['close'].shift(1)

    tr = pd.concat([
        high - low,
        (high - prev_close).abs(),
        (low  - prev_close).abs()
    ], axis=1).max(axis=1)

    # Wilder smoothing = EMA with alpha = 1/period
    return tr.ewm(alpha=1.0 / period, adjust=False).mean()


def compute_atr_ratio(df: pd.DataFrame,
                      atr_period: int = ATR_PERIOD,
                      avg_window: int = ATR_ROLLING_AVG) -> pd.Series:
    """
    Ratio of current ATR to its rolling mean.
    Values above 1.0 = above-average volatility.
    Values below 1.0 = below-average volatility.
    """
    atr = compute_atr(df, atr_period)
    return atr / atr.rolling(avg_window).mean()


# ─────────────────────────────────────────────────────────────────────────────
# Gate class
# ─────────────────────────────────────────────────────────────────────────────

class ATRVolatilityGate:
    """
    Two-sided volatility filter.

    Accepts a CBDR setup only when the session ATR sits within the
    valid band relative to its 20-day average:

        0.7 × avg  <  ATR  <  1.8 × avg

    Below 0.7 → market compressed, expansion unlikely.
    Above 1.8 → news/event flow, Judas pattern breaks down.

    Also validates that the Judas swing is structurally meaningful
    (deep enough to represent a genuine stop hunt, not noise).
    """

    def __init__(self,
                 low_thresh:  float = ATR_LOW_THRESH,
                 high_thresh: float = ATR_HIGH_THRESH,
                 judas_min_frac: float = JUDAS_MIN_ATR_FRAC):
        self.lo        = low_thresh
        self.hi        = high_thresh
        self.judas_min = judas_min_frac

    def session_is_valid(self,
                         current_atr: float,
                         avg_atr: float) -> tuple[bool, str]:
        """
        Check whether today's volatility regime supports a CBDR trade.

        Returns (valid: bool, reason: str)
        """
        if avg_atr <= 0:
            return False, "ATR average not yet available (insufficient history)"

        ratio = current_atr / avg_atr

        if ratio < self.lo:
            return False, (
                f"Session ATR too compressed ({ratio:.2f}× avg). "
                f"Market lacks energy for CBDR expansion."
            )
        if ratio > self.hi:
            return False, (
                f"Session ATR too explosive ({ratio:.2f}× avg). "
                f"Likely news-driven — Judas pattern unreliable."
            )

        return True, f"ATR valid ({ratio:.2f}× avg)"

    def judas_is_real(self,
                      judas_depth_price: float,
                      current_atr: float) -> tuple[bool, str]:
        """
        Validate that the Judas swing pierces the CBDR boundary by a
        meaningful amount relative to ATR — not just a random wick.

        Parameters
        ----------
        judas_depth_price : float
            Distance in price from CBDR Low to Judas Swing Low
            (or CBDR High to Judas Swing High for bearish setups).
        current_atr : float
            ATR at the time the Judas swing completes.
        """
        min_depth = self.judas_min * current_atr

        if judas_depth_price < min_depth:
            return False, (
                f"Judas sweep too shallow ({judas_depth_price:.5f} price, "
                f"min required {min_depth:.5f}). Likely noise."
            )

        return True, (
            f"Judas sweep valid ({judas_depth_price:.5f} > "
            f"{min_depth:.5f} min)"
        )

    def combined_check(self,
                       current_atr: float,
                       avg_atr: float,
                       judas_depth_price: float) -> dict:
        """
        Run both checks and return a structured result.
        Convenience wrapper for the main pipeline.
        """
        session_ok, session_msg = self.session_is_valid(current_atr, avg_atr)
        judas_ok,   judas_msg   = self.judas_is_real(judas_depth_price, current_atr)

        return {
            "pass":          session_ok and judas_ok,
            "session_valid": session_ok,
            "judas_valid":   judas_ok,
            "session_msg":   session_msg,
            "judas_msg":     judas_msg,
            "atr_ratio":     current_atr / avg_atr if avg_atr > 0 else None,
        }
