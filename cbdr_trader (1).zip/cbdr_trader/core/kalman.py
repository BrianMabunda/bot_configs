"""
core/kalman.py

Kalman filter for tracking CBDR High and Low levels.

Mathematical basis:
  The Kalman filter is the provably optimal linear estimator under
  Gaussian noise (Kálmán, 1960). For a static level we model:

    State transition:  x_k = x_{k-1} + w,  w ~ N(0, Q)
    Measurement:       z_k = x_k     + v,  v ~ N(0, R)

  The ratio R/Q is the only meaningful parameter:
    - High R/Q  → filter trusts its own estimate more than the raw tick
                  (smooth, slow to react) — correct for CBDR wicks
    - Low  R/Q  → filter tracks raw price closely (noisy)

  At R/Q = 10 the filter weights a new observation at roughly K ≈ 0.09,
  meaning it moves ~9% of the distance to each new print. This is
  appropriate for CBDR boundaries where engineered wicks are common.
"""

from config import KALMAN_R_OVER_Q


class KalmanLevel:
    """
    Single-state Kalman filter for one price level.
    Instantiate one for CBDR High, one for CBDR Low.

    Parameters
    ----------
    R_over_Q : float
        Ratio of measurement noise to process noise.
        Default 10.0 — do not tune without a holdout dataset.
    """

    def __init__(self, R_over_Q: float = KALMAN_R_OVER_Q):
        self.Q  = 1.0           # process noise (fixed; only ratio matters)
        self.R  = R_over_Q      # measurement noise
        self._x = None          # filtered state estimate
        self._P = 1.0           # estimate error covariance

    # ── public interface ──────────────────────────────────────────────────────

    def update(self, observation: float) -> float:
        """
        Feed one price observation (a candle High or Low).
        Returns the current filtered estimate.
        """
        if self._x is None:
            # cold start: initialise at first observation
            self._x = observation
            return self._x

        # ── Predict ──────────────────────────────────────────────────────────
        # Static model: we do not expect the CBDR boundary to drift, so the
        # state transition is identity. Process noise allows slow drift.
        P_pred = self._P + self.Q

        # ── Kalman gain ───────────────────────────────────────────────────────
        # K → 0  : ignore observation, trust prior
        # K → 1  : ignore prior, trust observation
        K = P_pred / (P_pred + self.R)

        # ── Update ────────────────────────────────────────────────────────────
        self._x = self._x + K * (observation - self._x)
        self._P = (1.0 - K) * P_pred
        return self._x

    def filtered_level(self) -> float:
        """Current filtered estimate. None if no observations yet."""
        return self._x

    def kalman_gain(self) -> float:
        """
        Current Kalman gain — diagnostic only.
        Converges quickly to a steady-state value for fixed R/Q.
        """
        P_pred = self._P + self.Q
        return P_pred / (P_pred + self.R)

    def reset(self):
        """
        Reset state at the start of each CBDR session.
        Must be called at 14:00 NY every trading day.
        """
        self._x = None
        self._P = 1.0

    def is_initialised(self) -> bool:
        return self._x is not None
