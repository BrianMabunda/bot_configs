"""
core/kelly.py

Kelly Criterion position sizing.

Mathematical basis:
  Kelly (1956) derived the optimal bet fraction f* that maximises
  the expected logarithmic growth rate of capital:

    f* = W - (1 - W) / R

  Where:
    W = empirical win probability
    R = average win / average loss  (risk-reward ratio)

  This is NOT heuristic — it follows directly from maximising
  E[log(wealth)] subject to the constraint that each trade's
  outcome is drawn from a Bernoulli(W) distribution.

  Why half-Kelly in practice?
    - Kelly assumes exact knowledge of W and R.
    - In reality both are estimated from finite samples.
    - The growth function is concave: underestimating is
      much safer than overestimating.
    - Half-Kelly sacrifices ~25% of optimal growth in exchange
      for a ~75% reduction in variance. This trade is almost
      always worth making.
    - Thorp (1997) demonstrated this empirically in both
      gambling and financial contexts.

  Negative Kelly (f* ≤ 0) means the system has negative expected
  log-growth. Do not trade when this occurs.
"""

from dataclasses import dataclass
from typing import Optional
import numpy as np
from config import (
    KELLY_FRACTION, KELLY_MIN_TRADES, KELLY_FALLBACK_RISK,
    KELLY_MAX_RISK_CAP, PIP_VALUE_PER_LOT, SL_BUFFER_PIPS
)


@dataclass
class KellyResult:
    """Output of the Kelly calculation."""
    full_kelly:    float
    half_kelly:    float
    quarter_kelly: float
    win_rate:      float
    avg_rr:        float
    edge:          float        # full_kelly = your edge per unit risked
    has_edge:      bool


def kelly_fraction(win_rate: float, avg_rr: float) -> KellyResult:
    """
    Compute Kelly fractions from empirical win rate and average R:R.

    Parameters
    ----------
    win_rate : float  — empirical proportion of trades that hit TP (0–1)
    avg_rr   : float  — average R-multiple on winning trades

    Returns KellyResult. Check `has_edge` before trading.
    """
    if not (0 < win_rate < 1):
        raise ValueError(f"win_rate must be in (0,1), got {win_rate}")
    if avg_rr <= 0:
        raise ValueError(f"avg_rr must be positive, got {avg_rr}")

    loss_rate = 1.0 - win_rate
    f_star    = win_rate - (loss_rate / avg_rr)

    if f_star <= 0:
        return KellyResult(0.0, 0.0, 0.0,
                           win_rate, avg_rr, f_star, has_edge=False)

    return KellyResult(
        full_kelly    = round(f_star,     6),
        half_kelly    = round(f_star / 2, 6),
        quarter_kelly = round(f_star / 4, 6),
        win_rate      = win_rate,
        avg_rr        = avg_rr,
        edge          = f_star,
        has_edge      = True
    )


def active_fraction(result: KellyResult,
                    mode: str = KELLY_FRACTION) -> float:
    """
    Return the fraction to use based on config mode.
    Caps at KELLY_MAX_RISK_CAP regardless of Kelly output.
    """
    if not result.has_edge:
        return 0.0

    fracs = {
        "full":    result.full_kelly,
        "half":    result.half_kelly,
        "quarter": result.quarter_kelly,
    }
    frac = fracs.get(mode, result.half_kelly)
    return min(frac, KELLY_MAX_RISK_CAP)


# ─────────────────────────────────────────────────────────────────────────────
# Trade history tracker
# ─────────────────────────────────────────────────────────────────────────────

class KellyTracker:
    """
    Maintains live trade history and recomputes Kelly dynamically.

    Designed to persist across sessions — serialise/deserialise
    via to_dict / from_dict for storage in a JSON sidecar file.
    """

    def __init__(self):
        self._wins:   list[float] = []   # R-multiples of winning trades
        self._losses: list[float] = []   # R-multiples of losing trades (positive values)

    # ── logging ───────────────────────────────────────────────────────────────

    def log_trade(self, rr_achieved: float, is_win: bool):
        """
        Record a completed trade.

        Parameters
        ----------
        rr_achieved : float  — R-multiple achieved (always positive)
        is_win      : bool   — True if TP1 was hit before SL
        """
        if rr_achieved < 0:
            raise ValueError("rr_achieved must be positive (loss magnitude, not signed PnL)")

        if is_win:
            self._wins.append(rr_achieved)
        else:
            self._losses.append(rr_achieved)

    # ── queries ───────────────────────────────────────────────────────────────

    @property
    def n_trades(self) -> int:
        return len(self._wins) + len(self._losses)

    @property
    def win_rate(self) -> Optional[float]:
        if self.n_trades == 0:
            return None
        return len(self._wins) / self.n_trades

    @property
    def avg_rr(self) -> Optional[float]:
        if not self._wins:
            return None
        return float(np.mean(self._wins))

    def current_kelly(self) -> KellyResult:
        """
        Current Kelly fractions based on all logged trades.
        Returns a zero-edge result if insufficient history.
        """
        if self.n_trades < KELLY_MIN_TRADES:
            # Not enough trades — return neutral (use fallback in sizing)
            return KellyResult(0.0, 0.0, 0.0, 0.5, 1.0, 0.0, has_edge=False)
        return kelly_fraction(self.win_rate, self.avg_rr)

    def risk_fraction(self) -> float:
        """
        The fraction of account equity to risk on the next trade.
        Uses fallback flat risk if Kelly history is insufficient.
        """
        result = self.current_kelly()
        if not result.has_edge:
            return KELLY_FALLBACK_RISK
        return active_fraction(result)

    def position_size_lots(self,
                            account_equity: float,
                            sl_pips: float,
                            pip_value: float = PIP_VALUE_PER_LOT) -> float:
        """
        Convert Kelly risk fraction → lot size.

        dollar_risk = equity × risk_fraction
        lots        = dollar_risk / (sl_pips × pip_value_per_lot)
        """
        risk_frac   = self.risk_fraction()
        dollar_risk = account_equity * risk_frac
        cost_per_lot = sl_pips * pip_value

        if cost_per_lot <= 0:
            raise ValueError(f"Invalid sl_pips={sl_pips} or pip_value={pip_value}")

        lots = dollar_risk / cost_per_lot
        return max(round(lots, 2), 0.01)   # minimum 0.01 lot

    # ── persistence ───────────────────────────────────────────────────────────

    def to_dict(self) -> dict:
        return {"wins": self._wins, "losses": self._losses}

    @classmethod
    def from_dict(cls, data: dict) -> "KellyTracker":
        tracker = cls()
        tracker._wins   = data.get("wins",   [])
        tracker._losses = data.get("losses", [])
        return tracker

    def summary(self) -> str:
        k = self.current_kelly()
        return (
            f"Trades: {self.n_trades} | "
            f"W: {(self.win_rate or 0):.1%} | "
            f"Avg R: {(self.avg_rr or 0):.2f} | "
            f"Half-Kelly: {k.half_kelly:.2%} | "
            f"Edge: {'YES' if k.has_edge else 'NO (using fallback)'}"
        )
