"""
data/feed.py  --  v2 (fixed naive-UTC + fallback)

Fix notes:
  - MT5 copy_rates_range requires NAIVE UTC datetimes (no tzinfo).
    Passing tz-aware datetimes silently returns None on many brokers.
  - Added copy_rates_from_pos fallback when range query fails.
  - Detailed error messages with troubleshooting steps.
"""

import time
import logging
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from typing import Optional

import pandas as pd

try:
    import MetaTrader5 as mt5
    MT5_AVAILABLE = True
except ImportError:
    MT5_AVAILABLE = False
    mt5 = None

from config import SYMBOL, NY_TIMEZONE
from core.atr_gate import compute_atr

log = logging.getLogger("feed")

_TF_MAP = {}
if MT5_AVAILABLE:
    _TF_MAP = {
        1:    mt5.TIMEFRAME_M1,
        5:    mt5.TIMEFRAME_M5,
        15:   mt5.TIMEFRAME_M15,
        30:   mt5.TIMEFRAME_M30,
        60:   mt5.TIMEFRAME_H1,
        240:  mt5.TIMEFRAME_H4,
        1440: mt5.TIMEFRAME_D1,
    }


def _naive_utc(dt: datetime) -> datetime:
    """
    MT5 requires naive datetimes that represent UTC.
    Convert tz-aware -> UTC -> strip tzinfo.
    """
    if dt.tzinfo is not None:
        dt = dt.astimezone(timezone.utc).replace(tzinfo=None)
    return dt


class MT5Feed:
    def __init__(self, symbol: str = SYMBOL):
        self.symbol     = symbol
        self._connected = False

    # -- connection -----------------------------------------------------------

    def connect(self) -> bool:
        if not MT5_AVAILABLE:
            log.error("MetaTrader5 package not installed. Run: pip install MetaTrader5")
            return False

        if not mt5.initialize():
            log.error(f"mt5.initialize() failed -- {mt5.last_error()}")
            return False

        info = mt5.symbol_info(self.symbol)
        if info is None:
            log.error(
                f"Symbol '{self.symbol}' not found in MT5 terminal.\n"
                f"  MT5 error : {mt5.last_error()}\n"
                f"  Fix       : Open Market Watch (Ctrl+M), right-click -> Show All,\n"
                f"              then verify the exact symbol name your broker uses\n"
                f"              (e.g. 'EURUSD' vs 'EURUSDm' vs 'EURUSD.')."
            )
            mt5.shutdown()
            return False

        if not info.visible:
            if not mt5.symbol_select(self.symbol, True):
                log.error(f"Could not add '{self.symbol}' to Market Watch: {mt5.last_error()}")
                mt5.shutdown()
                return False
            time.sleep(0.5)

        acct = mt5.account_info()
        self._connected = True
        log.info(
            f"MT5 connected | Symbol: {self.symbol} | "
            f"Spread: {info.spread} pts | Digits: {info.digits} | "
            f"Server: {acct.server if acct else 'unknown'}"
        )
        return True

    def disconnect(self):
        if MT5_AVAILABLE and self._connected:
            mt5.shutdown()
        self._connected = False
        log.info("MT5 disconnected")

    # -- historical data ------------------------------------------------------

    def get_ohlcv(self,
                  timeframe_minutes: int,
                  start: datetime,
                  end: Optional[datetime] = None,
                  atr_period: int = 14) -> pd.DataFrame:
        """
        Fetch OHLCV bars for the requested range.

        MT5 copy_rates_range MUST receive naive (no tzinfo) UTC datetimes.
        Tz-aware datetimes silently return None on most brokers.
        """
        if not self._connected:
            raise RuntimeError("Not connected. Call connect() first.")

        tf = _TF_MAP.get(timeframe_minutes)
        if tf is None:
            raise ValueError(
                f"Unsupported timeframe: {timeframe_minutes} min. "
                f"Valid options: {sorted(_TF_MAP.keys())}"
            )

        end = end or datetime.now(timezone.utc)

        # Convert to naive UTC -- critical fix
        s = _naive_utc(start)
        e = _naive_utc(end)

        log.info(
            f"Requesting {self.symbol} M{timeframe_minutes}: "
            f"{s.date()} to {e.date()} (naive UTC)"
        )

        rates = mt5.copy_rates_range(self.symbol, tf, s, e)

        # -- fallback: bar count query ----------------------------------------
        if rates is None or len(rates) == 0:
            err = mt5.last_error()
            log.warning(
                f"copy_rates_range returned nothing (MT5 error: {err}). "
                f"Trying copy_rates_from_pos fallback..."
            )
            bars_per_day = (24 * 60) // timeframe_minutes
            n_bars = (e - s).days * bars_per_day + 1000
            rates = mt5.copy_rates_from_pos(self.symbol, tf, 0, min(n_bars, 99999))

            if rates is None or len(rates) == 0:
                log.error(
                    f"\n{'='*60}\n"
                    f"  DATA FETCH FAILED for {self.symbol} M{timeframe_minutes}\n"
                    f"  MT5 error code: {mt5.last_error()}\n"
                    f"{'='*60}\n"
                    f"  Common fixes:\n"
                    f"  1. Scroll your MT5 chart back to 2021 manually to\n"
                    f"     trigger a full history download, then re-run.\n"
                    f"  2. In MT5: Tools -> Options -> Charts, set\n"
                    f"     'Max bars in chart' to 500000+.\n"
                    f"  3. Some brokers limit history on free accounts.\n"
                    f"     Try --years 2 instead of --years 4.\n"
                    f"  4. Ensure the terminal is logged in (not just open).\n"
                    f"{'='*60}"
                )
                return pd.DataFrame()

            log.info(f"Fallback returned {len(rates)} bars -- trimming to range.")

        # -- build DataFrame --------------------------------------------------
        df = pd.DataFrame(rates)
        df['time'] = pd.to_datetime(df['time'], unit='s', utc=True)
        df = df.rename(columns={'tick_volume': 'volume'}, errors='ignore')
        df = df[['time', 'open', 'high', 'low', 'close', 'volume']].copy()
        df = df.set_index('time').sort_index()

        # Trim to requested range (essential after from_pos fallback)
        s_ts = pd.Timestamp(s, tz='UTC')
        e_ts = pd.Timestamp(e, tz='UTC')
        df   = df.loc[s_ts:e_ts]

        if df.empty:
            log.warning(
                "Bars were fetched but none fall within the requested date range.\n"
                "This usually means your broker's history starts later than requested.\n"
                "Try: python main.py --mode backtest --years 2"
            )
            return pd.DataFrame()

        # -- attach ATR -------------------------------------------------------
        df['atr_14']    = compute_atr(df, atr_period)
        df['atr_20avg'] = df['atr_14'].rolling(20).mean()

        ny_tz = ZoneInfo(NY_TIMEZONE)
        df['ny_hour'] = df.index.tz_convert(ny_tz).hour
        df['dow']     = df.index.tz_convert(ny_tz).dayofweek

        log.info(
            f"Loaded {len(df):,} bars | "
            f"{df.index.min().date()} -> {df.index.max().date()}"
        )
        return df

    def get_years(self,
                  timeframe_minutes: int,
                  years: int = 4,
                  atr_period: int = 14) -> pd.DataFrame:
        end   = datetime.now(timezone.utc)
        start = end - timedelta(days=365 * years)
        return self.get_ohlcv(timeframe_minutes, start, end, atr_period)

    # -- live -----------------------------------------------------------------

    def get_latest_candle(self, timeframe_minutes: int) -> Optional[dict]:
        if not self._connected:
            return None
        tf    = _TF_MAP.get(timeframe_minutes)
        rates = mt5.copy_rates_from_pos(self.symbol, tf, 0, 2)
        if rates is None or len(rates) < 2:
            return None
        bar   = rates[1]
        ny_tz = ZoneInfo(NY_TIMEZONE)
        ts    = pd.Timestamp(bar['time'], unit='s', tz='UTC')
        return {
            'time':    ts,
            'open':    bar['open'],
            'high':    bar['high'],
            'low':     bar['low'],
            'close':   bar['close'],
            'volume':  bar['tick_volume'],
            'ny_hour': ts.tz_convert(ny_tz).hour,
            'dow':     ts.tz_convert(ny_tz).dayofweek,
        }

    def get_account_equity(self) -> float:
        if not self._connected:
            return 0.0
        info = mt5.account_info()
        return float(info.equity) if info else 0.0

    def get_weekly_extremes(self) -> tuple[float, float]:
        now   = datetime.now(timezone.utc)
        start = now - timedelta(days=7)
        rates = mt5.copy_rates_range(
            self.symbol, mt5.TIMEFRAME_D1,
            _naive_utc(start), _naive_utc(now)
        )
        if rates is None or len(rates) == 0:
            return 0.0, float('inf')
        return (
            max(r['high'] for r in rates),
            min(r['low']  for r in rates)
        )

    def wait_for_new_bar(self,
                         timeframe_minutes: int,
                         poll_interval_seconds: float = 1.0) -> dict:
        last      = self.get_latest_candle(timeframe_minutes)
        last_time = last['time'] if last else None
        while True:
            time.sleep(poll_interval_seconds)
            current = self.get_latest_candle(timeframe_minutes)
            if current and current['time'] != last_time:
                return current
