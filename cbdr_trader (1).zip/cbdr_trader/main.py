"""
main.py — CBDR Trading System Entry Point

Usage
-----
  # Run walk-forward backtest on 4 years of data
  python main.py --mode backtest --years 4

  # Run live bot (requires MT5 connected and account logged in)
  python main.py --mode live

  # Backtest with a specific Kalman R/Q ratio
  python main.py --mode backtest --kalman-rq 15

Architecture (live mode)
-------------------------
  main loop
    │
    ├─ MT5Feed          → fetches new 5-min candles
    ├─ CBDRSession      → state machine (Kalman + ATR gate + Kelly)
    ├─ MT5Broker        → executes orders / manages partial closes
    └─ KellyTracker     → persists across sessions (JSON sidecar)

  No threads. No async. One clean polling loop.
  The only blocking call is feed.wait_for_new_bar() — it sleeps
  until the next 5-minute candle closes, consuming negligible CPU.

Design constraints
------------------
  - One trade per session maximum (MAX_OPEN_TRADES = 1)
  - Daily drawdown limit halts the broker for the rest of the day
  - Weekly drawdown limit halts until manual reset
  - Kelly state persists to disk so it survives restarts
  - All parameters in config.py — nothing hardcoded here
"""

import argparse
import json
import logging
import sys
import time
from datetime import datetime, timezone
from pathlib  import Path
from zoneinfo import ZoneInfo

from utils.logger    import setup_logging
from data.feed       import MT5Feed
from backtest.walk_forward import run_backtest
from core.cbdr       import CBDRSession, SessionState
from core.kelly      import KellyTracker
from execution.broker import MT5Broker
from config import (
    SYMBOL, KALMAN_R_OVER_Q, NO_TRADE_DAYS,
    NY_TIMEZONE, TRADE_LOG_CSV, RESULTS_DIR
)

log = logging.getLogger("main")

KELLY_STATE_PATH = Path("logs/kelly_state.json")


# ─────────────────────────────────────────────────────────────────────────────
# Kelly persistence
# ─────────────────────────────────────────────────────────────────────────────

def load_kelly() -> KellyTracker:
    if KELLY_STATE_PATH.exists():
        with open(KELLY_STATE_PATH) as f:
            data = json.load(f)
        tracker = KellyTracker.from_dict(data)
        log.info(f"Kelly state loaded — {tracker.summary()}")
        return tracker
    log.info("No Kelly state found — starting fresh (using fallback risk).")
    return KellyTracker()


def save_kelly(tracker: KellyTracker):
    KELLY_STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(KELLY_STATE_PATH, 'w') as f:
        json.dump(tracker.to_dict(), f)
    log.debug("Kelly state saved.")


# ─────────────────────────────────────────────────────────────────────────────
# Backtest mode
# ─────────────────────────────────────────────────────────────────────────────

def run_backtest_mode(years: int, kalman_rq: float):
    log.info(f"═══ BACKTEST MODE — {years} years | Kalman R/Q: {kalman_rq} ═══")

    feed = MT5Feed(SYMBOL)
    if not feed.connect():
        log.error("Could not connect to MT5. Ensure terminal is open.")
        sys.exit(1)

    log.info(f"Fetching {years} years of 5-min data for {SYMBOL}...")
    df = feed.get_years(timeframe_minutes=5, years=years)
    feed.disconnect()

    if df.empty:
        log.error("No data returned. Check MT5 connection and symbol.")
        sys.exit(1)

    df.attrs['symbol'] = SYMBOL
    run_backtest(df, kalman_rq=kalman_rq, save=True)


# ─────────────────────────────────────────────────────────────────────────────
# Live trading mode
# ─────────────────────────────────────────────────────────────────────────────

def run_live_mode(kalman_rq: float):
    log.info("═══ LIVE MODE ═══")
    log.info(f"Symbol: {SYMBOL} | Kalman R/Q: {kalman_rq}")

    # ── connect ───────────────────────────────────────────────────────────────
    feed = MT5Feed(SYMBOL)
    if not feed.connect():
        log.error("MT5 connection failed. Exiting.")
        sys.exit(1)

    broker = MT5Broker(SYMBOL)
    kelly  = load_kelly()
    ny_tz  = ZoneInfo(NY_TIMEZONE)

    # ── equity snapshots for drawdown tracking ────────────────────────────────
    equity = feed.get_account_equity()
    broker.reset_weekly(equity)
    broker.reset_daily(equity)
    log.info(f"Starting equity: {equity:.2f}")

    # ── session state ─────────────────────────────────────────────────────────
    session:     CBDRSession | None = None
    last_date    = None
    last_week    = None

    log.info("Entering main loop — waiting for bars...")

    try:
        while True:
            # ── wait for next 5-min candle ────────────────────────────────────
            try:
                candle = feed.wait_for_new_bar(timeframe_minutes=5,
                                               poll_interval_seconds=1.0)
            except Exception as e:
                log.error(f"Feed error: {e}. Retrying in 30s...")
                time.sleep(30)
                continue

            now_ny   = candle['time'].tz_convert(ny_tz)
            today    = now_ny.date()
            this_week = now_ny.isocalendar()[1]   # ISO week number
            ny_hour  = now_ny.hour

            # ── weekly reset ──────────────────────────────────────────────────
            if last_week is None or this_week != last_week:
                equity = feed.get_account_equity()
                broker.reset_weekly(equity)
                save_kelly(kelly)
                last_week = this_week
                log.info(f"Weekly reset — equity: {equity:.2f}")

            # ── daily reset ───────────────────────────────────────────────────
            if last_date is None or today != last_date:
                equity = feed.get_account_equity()
                broker.reset_daily(equity)

                # Skip no-trade days
                dow = now_ny.weekday()
                if dow in NO_TRADE_DAYS or dow >= 5:
                    log.info(f"No-trade day ({now_ny.strftime('%A')}) — skipping.")
                    last_date = today
                    continue

                # Create fresh session for the new day
                weekly_high, weekly_low = feed.get_weekly_extremes()
                session = CBDRSession(kelly, equity, kalman_rq=kalman_rq)
                session.set_weekly_levels(weekly_high, weekly_low)

                if broker.is_halted:
                    session.halt("Broker daily halt — risk limit reached")

                last_date = today
                log.info(f"New session — {today} | Equity: {equity:.2f}")

            if session is None:
                continue

            # ── fetch current ATR ─────────────────────────────────────────────
            # Pull last 30 H1 bars to compute ATR for the gate
            try:
                from datetime import timedelta
                h1_end   = candle['time']
                h1_start = h1_end - timedelta(days=30)
                h1_df    = feed.get_ohlcv(60, h1_start, h1_end)
                current_atr = float(h1_df['atr_14'].iloc[-1])   if not h1_df.empty else 0.001
                avg_atr     = float(h1_df['atr_20avg'].iloc[-1]) if not h1_df.empty else 0.001
            except Exception as e:
                log.warning(f"Could not fetch ATR: {e} — using defaults")
                current_atr = 0.001
                avg_atr     = 0.001

            # ── run session logic ─────────────────────────────────────────────
            action = session.on_candle(
                candle=candle,
                current_atr=current_atr,
                avg_atr=avg_atr,
                ny_hour=ny_hour
            )

            # ── execute action ────────────────────────────────────────────────
            if action is not None:
                equity = feed.get_account_equity()
                broker.execute_action(action, equity)

                # Persist Kelly after every trade close
                if action['action'] in ('close_sl', 'close_tp1',
                                        'close_tp2', 'close_tp3'):
                    save_kelly(kelly)

            # ── heartbeat log ─────────────────────────────────────────────────
            log.debug(
                f"{now_ny.strftime('%H:%M')} NY | "
                f"State: {session.state.name} | "
                f"O:{candle['open']:.5f} H:{candle['high']:.5f} "
                f"L:{candle['low']:.5f} C:{candle['close']:.5f}"
            )

    except KeyboardInterrupt:
        log.info("Shutdown requested by user (Ctrl+C).")
    finally:
        save_kelly(kelly)
        feed.disconnect()
        log.info("Clean shutdown complete.")


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────

def parse_args():
    parser = argparse.ArgumentParser(
        description="CBDR Trading System — Kalman + ATR Gate + Kelly"
    )
    parser.add_argument(
        '--mode',
        choices=['backtest', 'live'],
        required=True,
        help="Run mode: 'backtest' for walk-forward validation, 'live' for live trading"
    )
    parser.add_argument(
        '--years',
        type=int,
        default=4,
        help="Years of historical data for backtesting (default: 4)"
    )
    parser.add_argument(
        '--kalman-rq',
        type=float,
        default=KALMAN_R_OVER_Q,
        help=f"Kalman R/Q ratio (default: {KALMAN_R_OVER_Q}). "
             "This is the ONLY parameter you should tune — and only after "
             "reviewing your pair's wick characteristics on the holdout set."
    )
    parser.add_argument(
        '--log-level',
        default='INFO',
        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
        help="Console log level (default: INFO)"
    )
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    setup_logging(level=args.log_level)

    log.info("─" * 55)
    log.info("  CBDR Trading System")
    log.info(f"  Mode: {args.mode.upper()} | Symbol: {SYMBOL}")
    log.info("─" * 55)

    if args.mode == "backtest":
        run_backtest_mode(years=args.years, kalman_rq=args.kalman_rq)
    else:
        run_live_mode(kalman_rq=args.kalman_rq)
