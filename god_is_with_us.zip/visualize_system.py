"""
System diagnostics and trading discipline (read before going live)
=================================================================

Best-practice way to trade this stack
-------------------------------------
1. Risk first: risk a small fixed fraction of equity per trade (e.g. 0.25-1%%); never
   size purely from backtest pips. Use broker min lot / stops level rules.
2. Match the code path: live_bot.py uses the same H1 AR + Jensen + ATR edge + CUSUM as
   backtest.py (hourly bars). Optional M15 Trigg-Leach chart is for research only.
3. Costs: assume spread + commission + slippage worse than backtest defaults; if net
   edge does not survive realistic costs in research, do not trade it live.
4. CUSUM / monitoring: respect skip signals when the monitor flags deterioration;
   that is a feature, not noise.
5. Demo first: run on demo with the same symbol, server, and filling mode until
   execution and logs look correct for several sessions.
6. No lookahead: the plots below are walk-forward (each point uses only past bars).

Generates two PNG reports:
  - *_h1_ar_diagnostics.png  : research / backtest pipeline (AR + ATR edge)
  - *_m15_tl_diagnostics.png : optional Trigg-Leach on M15 (not used by live_bot)

Run (from project folder, trading_bot env):
  python visualize_system.py --symbol GBPJPY
"""
from __future__ import annotations

import argparse
from datetime import datetime
from typing import Optional

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import MetaTrader5 as mt5
import numpy as np
import pandas as pd
from matplotlib.gridspec import GridSpec

from ar_modeler import ARModeler
from data_engine import DataEngine
from quant_filters import QuantFilters
from trade_executor import TradeExecutor
from mt5_session import init_mt5

DEFAULT_ROUND_TRIP_SPREAD_PIPS = {"EURUSD": 1.6, "GBPJPY": 3.0, "USDJPY": 2.0}

# ---------------------------------------------------------------------------
# H1 pipeline (aligned with backtest.py)
# ---------------------------------------------------------------------------
_arm_h1: dict = {}


def _pretrain_h1_ar(symbol: str, train_df: pd.DataFrame) -> None:
    arm = ARModeler(max_lags=8)
    log_prices = np.log(train_df["close"])
    win = min(500, max(50, len(log_prices) - 1))
    recent_log = log_prices.iloc[-win:]
    stationary = recent_log.diff().dropna()
    if len(stationary) < arm.max_lags + 2:
        arm.fit_ar_model(stationary, refit_lags=True)
    else:
        arm.select_optimal_lags(stationary, criterion="aic")
    _arm_h1[symbol] = arm


def h1_pipeline(history_df: pd.DataFrame, symbol: str):
    log_prices = np.log(history_df["close"])
    recent_log = log_prices.iloc[-500:]
    stationary = recent_log.diff().dropna()

    if symbol not in _arm_h1:
        _arm_h1[symbol] = ARModeler(max_lags=8)

    arm = _arm_h1[symbol]
    arm.fit_ar_model(stationary, refit_lags=False)

    next_ret_pred = arm.predict_next(stationary)
    sigma_sq = arm.residual_variance

    last_log = log_prices.iloc[-1]
    forecast_price = np.exp(last_log + next_ret_pred + (0.5 * sigma_sq))

    executor = TradeExecutor(symbol=symbol)
    atr = executor.calculate_atr(history_df, period=14)

    return forecast_price, atr, float(sigma_sq), int(arm.optimal_lags or -1)


def _pip_mult(symbol: str) -> float:
    return 100.0 if "JPY" in symbol else 10000.0


def run_h1_walkforward(
    symbol: str,
    df: pd.DataFrame,
    initial_train_size: int,
    atr_edge_multiplier: float,
    spread_round_trip_pips: float,
) -> pd.DataFrame:
    _arm_h1.clear()
    _pretrain_h1_ar(symbol, df.iloc[:initial_train_size])

    rows = []
    pm = _pip_mult(symbol)
    for i in range(initial_train_size, len(df)):
        hist = df.iloc[:i]
        cur = float(hist["close"].iloc[-1])
        actual_next = float(df["close"].iloc[i])
        try:
            fc, atr, sigma_sq, ar_p = h1_pipeline(hist, symbol)
        except Exception:
            continue

        edge = abs(fc - cur)
        thr = atr * atr_edge_multiplier
        passed = edge >= thr
        direction = 1 if fc > cur else -1
        raw = (actual_next - cur) * direction
        pips_gross = raw * pm
        pips_net = pips_gross - spread_round_trip_pips

        rows.append(
            {
                "time": df.index[i],
                "close_prev": cur,
                "close_next": actual_next,
                "forecast": fc,
                "atr": atr,
                "edge": edge,
                "threshold": thr,
                "passed_edge": passed,
                "sigma_sq": sigma_sq,
                "ar_p": ar_p,
                "pips_gross": pips_gross,
                "pips_net": pips_net,
            }
        )

    return pd.DataFrame(rows).set_index("time")


def plot_h1_dashboard(
    symbol: str,
    out_path: str,
    initial_train_size: int = 1500,
    atr_edge_multiplier: float = 0.15,
    spread_round_trip_pips: Optional[float] = None,
) -> None:
    if spread_round_trip_pips is None:
        spread_round_trip_pips = float(DEFAULT_ROUND_TRIP_SPREAD_PIPS.get(symbol, 2.0))

    engine = DataEngine(symbol=symbol, timeframe=mt5.TIMEFRAME_H1, required_bars=6000)
    raw = engine.fetch_data()
    df = engine.stochastic_imputation(raw, reindex_freq="1h")

    wf = run_h1_walkforward(
        symbol,
        df,
        initial_train_size=initial_train_size,
        atr_edge_multiplier=atr_edge_multiplier,
        spread_round_trip_pips=spread_round_trip_pips,
    )

    fig = plt.figure(figsize=(14, 16))
    gs = GridSpec(6, 1, figure=fig, height_ratios=[1.2, 0.9, 0.9, 0.9, 1.0, 0.35], hspace=0.35)

    ax1 = fig.add_subplot(gs[0, 0])
    ax2 = fig.add_subplot(gs[1, 0], sharex=ax1)
    ax3 = fig.add_subplot(gs[2, 0], sharex=ax1)
    ax4 = fig.add_subplot(gs[3, 0], sharex=ax1)
    ax5 = fig.add_subplot(gs[4, 0], sharex=ax1)
    ax6 = fig.add_subplot(gs[5, 0], sharex=ax1)

    ax1.plot(wf.index, wf["close_next"], label="Actual close (bar end)", color="black", lw=1)
    ax1.plot(wf.index, wf["forecast"], label="1-step forecast (AR+log)", color="tab:blue", alpha=0.85, lw=1)
    ax1.set_ylabel("Price")
    ax1.legend(loc="upper left", fontsize=8)
    ax1.set_title(
        f"H1 AR pipeline | {symbol} | train={initial_train_size} bars | "
        f"AR p={wf['ar_p'].iloc[-1] if len(wf) else 'n/a'}"
    )
    ax1.grid(True, alpha=0.3)

    err = wf["close_next"] - wf["forecast"]
    ax2.plot(wf.index, err, color="tab:purple", lw=0.8)
    ax2.axhline(0, color="gray", lw=0.8)
    ax2.set_ylabel("Error\n(next - fc)")

    ax3.fill_between(
        wf.index, 0, wf["edge"], color="tab:green", alpha=0.25, label="|forecast - prev close|"
    )
    ax3.plot(wf.index, wf["threshold"], color="tab:red", lw=1, label=f"ATR * {atr_edge_multiplier}")
    ax3.set_ylabel("Edge vs filter")
    ax3.legend(loc="upper left", fontsize=7)

    passed = wf["passed_edge"]
    ax4.scatter(
        wf.index[passed],
        wf.loc[passed, "pips_net"],
        s=8,
        c="tab:green",
        alpha=0.6,
        label="Net pips if traded (edge ok)",
    )
    ax4.scatter(
        wf.index[~passed],
        np.zeros((~passed).sum()),
        s=4,
        c="lightgray",
        alpha=0.5,
        label="No trade (edge too small)",
    )
    ax4.set_ylabel("Net pips\n(single bar)")

    traded = wf[passed]
    if not traded.empty:
        ax5.plot(traded.index, traded["pips_net"].cumsum(), color="tab:blue", lw=1.2, label="Cum net pips (filtered)")
    ax5.axhline(0, color="black", lw=0.8)
    ax5.set_ylabel("Cumulative\nnet pips")
    ax5.legend(loc="upper left", fontsize=7)

    ax6.axis("off")
    info = (
        f"Forecast: log return AR on last 500 log closes (diff), AIC lag once per run after pretrain. "
        f"Price fc = exp(last_log + r_hat + 0.5*sigma^2). "
        f"Round-trip cost assumed: {spread_round_trip_pips:.2f} pips. "
        f"Bars in walk-forward: {len(wf)}."
    )
    ax6.text(0.01, 0.5, info, fontsize=8, va="center", family="monospace", wrap=True)

    ax1.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m-%d"))
    plt.setp(ax1.get_xticklabels(), visible=True)
    plt.xticks(rotation=25)
    fig.align_labels()
    plt.tight_layout()
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"[PLOT] H1 diagnostics saved: {out_path}")


# ---------------------------------------------------------------------------
# M15 live-style pipeline (Trigg-Leach + Jensen)
# ---------------------------------------------------------------------------
_arm_m15: Optional[ARModeler] = None


def _tl_log_sigma(recent_logs: pd.Series, tl_forecasts: pd.Series) -> float:
    err = []
    for t in range(1, len(recent_logs)):
        err.append(recent_logs.iloc[t] - tl_forecasts.iloc[t - 1])
    if not err:
        return 1e-12
    return float(np.var(err))


def run_m15_walkforward(
    symbol: str,
    df: pd.DataFrame,
    start_idx: int,
    tl_window: int,
    base_alpha: float,
) -> pd.DataFrame:
    global _arm_m15
    _arm_m15 = ARModeler(max_lags=20)

    rows = []
    for i in range(start_idx, len(df)):
        hist = df.iloc[:i]
        log_prices = QuantFilters.log_transform(hist["close"])
        recent_logs = log_prices.iloc[-tl_window:]
        if len(recent_logs) < 10:
            continue
        tl_fc, tl_alpha = _arm_m15.trigg_leach_adaptive_forecast(
            recent_logs,
            initial_forecasts=[recent_logs.iloc[0]],
            base_alpha=base_alpha,
        )
        sig = _tl_log_sigma(recent_logs, tl_fc)
        fc_price = float(np.exp(tl_fc.iloc[-1] + 0.5 * sig))
        cur = float(hist["close"].iloc[-1])
        rows.append(
            {
                "time": df.index[i],
                "close_next": float(df["close"].iloc[i]),
                "forecast_price": fc_price,
                "log_fc": float(tl_fc.iloc[-1]),
                "alpha_tl": float(tl_alpha.iloc[-1]),
                "sigma2_log": sig,
                "current": cur,
            }
        )

    return pd.DataFrame(rows).set_index("time")


def plot_m15_dashboard(
    symbol: str,
    out_path: str,
    required_bars: int = 5000,
    plot_walkforward_bars: int = 400,
    tl_window: int = 200,
    base_alpha: float = 0.2,
) -> None:
    engine = DataEngine(symbol=symbol, timeframe=mt5.TIMEFRAME_M15, required_bars=required_bars)
    raw = engine.fetch_data()
    df = engine.stochastic_imputation(raw, reindex_freq=None)

    start_idx = max(tl_window + 50, len(df) - plot_walkforward_bars)
    wf = run_m15_walkforward(symbol, df, start_idx=start_idx, tl_window=tl_window, base_alpha=base_alpha)

    fig = plt.figure(figsize=(14, 14))
    gs = GridSpec(5, 1, figure=fig, height_ratios=[1.1, 1.0, 0.8, 0.8, 0.35], hspace=0.35)

    ax1 = fig.add_subplot(gs[0, 0])
    ax2 = fig.add_subplot(gs[1, 0], sharex=ax1)
    ax3 = fig.add_subplot(gs[2, 0], sharex=ax1)
    ax4 = fig.add_subplot(gs[3, 0], sharex=ax1)
    ax5 = fig.add_subplot(gs[4, 0], sharex=ax1)

    ax1.plot(wf.index, wf["close_next"], color="black", lw=1, label="Actual close (next bar)")
    ax1.plot(wf.index, wf["forecast_price"], color="tab:orange", lw=1, alpha=0.9, label="TL forecast price (Jensen)")
    ax1.set_ylabel("Price")
    ax1.legend(loc="upper left", fontsize=8)
    ax1.set_title(f"M15 Trigg-Leach (log) | {symbol} | window={tl_window} | base_alpha={base_alpha}")
    ax1.grid(True, alpha=0.3)

    log_act = np.log(wf["close_next"].values)
    ax2.plot(wf.index, log_act, label="log(close) next", color="black", lw=0.8)
    ax2.plot(wf.index, wf["log_fc"], color="tab:orange", lw=0.9, label="TL log forecast (end of window)")
    ax2.set_ylabel("Log level")
    ax2.legend(loc="upper left", fontsize=7)

    ax3.plot(wf.index, wf["alpha_tl"], color="tab:green", lw=1)
    ax3.set_ylabel("Trigg-Leach\nalpha")
    ax3.set_ylim(0, 1)
    ax3.grid(True, alpha=0.3)

    ax4.plot(wf.index, np.sqrt(np.maximum(wf["sigma2_log"], 1e-12)), color="tab:red", lw=1)
    ax4.set_ylabel("sigma\n(log space)")

    ax5.axis("off")
    ax5.text(
        0.01,
        0.5,
        "Optional M15 path: Trigg-Leach on log closes; live_bot is H1 AR (see H1 figure). "
        "CUSUM is not shown on this chart.",
        fontsize=8,
        va="center",
        family="monospace",
    )

    ax1.xaxis.set_major_formatter(mdates.DateFormatter("%m-%d %H:%M"))
    plt.xticks(rotation=25)
    plt.tight_layout()
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"[PLOT] M15 diagnostics saved: {out_path}")


def main():
    p = argparse.ArgumentParser(description="Visualize H1 AR and M15 Trigg-Leach pipelines.")
    p.add_argument("--symbol", default="GBPJPY", help="MT5 symbol")
    p.add_argument("--out-prefix", default="", help="Output filename prefix")
    p.add_argument("--h1-only", action="store_true")
    p.add_argument("--m15-only", action="store_true")
    args = p.parse_args()

    if not init_mt5():
        print("MT5 init failed.")
        return

    try:
        prefix = args.out_prefix or f"system_diag_{datetime.now().strftime('%Y%m%d_%H%M')}"
        sym = args.symbol

        if not args.m15_only:
            plot_h1_dashboard(sym, f"{prefix}_h1_ar_diagnostics.png")
        if not args.h1_only:
            plot_m15_dashboard(sym, f"{prefix}_m15_tl_diagnostics.png")
    finally:
        mt5.shutdown()


if __name__ == "__main__":
    main()
