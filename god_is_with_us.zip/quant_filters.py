import pandas as pd
import numpy as np
import statsmodels.api as sm

class QuantFilters:
    """
    Statistical preprocessing pipeline for M15 currency price series.
    """

    # ------------------------------------------------------------------ #
    #  1. LOG TRANSFORM                                                    #
    # ------------------------------------------------------------------ #
    @staticmethod
    def log_transform(series):
        """
        Applies Natural Log Transformation (λ=0) to stabilise variance.
        Returns log(series). Series must be strictly positive.
        """
        if (series <= 0).any():
            raise ValueError("Log transform requires strictly positive values.")
        return np.log(series)

    # ------------------------------------------------------------------ #
    #  2. VARIOGRAM DIAGNOSTIC                                             #
    # ------------------------------------------------------------------ #
    @staticmethod
    def calculate_variogram(series, max_lags=100):
        """
        Calculates Variogram G_k = (1 - ρ_k) / (1 - ρ_1).

        Interpretation:
          - Stationary series:   G_k reaches asymptote ≈ 1.0.
          - Non-stationary:      G_k increases monotonically (as seen in
                                 the GBPJPY test — good, expected result).

        Args:
            series:   Raw or log-transformed price series.
            max_lags: Number of lags to evaluate.

        Returns:
            np.ndarray: G_k values for lags 0 ... max_lags.
        """
        acf_vals = sm.tsa.acf(series.dropna(), nlags=max_lags, fft=True)
        rho_1 = acf_vals[1]

        if abs(1 - rho_1) < 1e-10:
            return np.ones(max_lags + 1)  # Perfectly integrated — flat line at 1

        variogram = (1 - acf_vals) / (1 - rho_1)
        return variogram

    # ------------------------------------------------------------------ #
    #  3. NESTED SEASONAL DIFFERENCING (ORDER FIXED)                      #
    # ------------------------------------------------------------------ #
    @staticmethod
    def apply_nested_differencing(series):
        """
        Applies sequential Lag-d Seasonal Differencing to strip nested cycles.

        CORRECTED ORDER (v2): Seasonal diffs are applied BEFORE trend diff.
        Applying trend diff first can absorb part of the seasonal signal,
        making the seasonal components harder to model.

        Sequence:
            1. Intraday  (Lag 96  = 24h at M15)
            2. Weekly    (Lag 480 = 5 trading days)
            3. Monthly   (Lag 1920 = 20 trading days / 4 weeks)
            4. Trend     (Lag 1  — linear drift removal)

        Data loss: 96 + 480 + 1920 + 1 = 2,497 bars (leading NaN dropped).
        From 99,999 bars → ~97,502 usable stationary observations.

        Args:
            series (pd.Series): Log-transformed close price.

        Returns:
            pd.Series: Stationary residual series with NaN rows removed.
        """
        # Seasonal layers first
        d1 = series.diff(96)     # Strip intraday cycle
        d2 = d1.diff(480)        # Strip weekly cycle
        d3 = d2.diff(1920)       # Strip monthly cycle

        # Trend removal last
        d4 = d3.diff(1)

        result = d4.dropna()
        print(f"[QuantFilters] Nested differencing: "
              f"{len(series):,} → {len(result):,} stationary observations.")
        return result

    # ------------------------------------------------------------------ #
    #  4. DATA SPLITTING FOR VALIDATION (NEW — Proposal Step 5)           #
    # ------------------------------------------------------------------ #
    @staticmethod
    def train_test_split(series, train_ratio=0.80):
        """
        Splits a chronological series into fitting and forecasting segments.
        Temporal ordering is strictly preserved — no shuffling.

        Args:
            series (pd.Series): Stationary residual series.
            train_ratio (float): Proportion allocated to fitting (default 0.80).

        Returns:
            Tuple[pd.Series, pd.Series]: (train_series, test_series)
        """
        split_idx = int(len(series) * train_ratio)
        train = series.iloc[:split_idx]
        test  = series.iloc[split_idx:]

        print(f"[QuantFilters] Split: {len(train):,} train / {len(test):,} test "
              f"({train_ratio*100:.0f}% / {(1-train_ratio)*100:.0f}%)")
        return train, test

    # ------------------------------------------------------------------ #
    #  5. FORECAST ACCURACY METRICS (NEW)                                 #
    # ------------------------------------------------------------------ #
    @staticmethod
    def forecast_accuracy(actuals, forecasts):
        """
        Calculates standard forecast accuracy metrics for model validation.

        Metrics:
            MAE   — Mean Absolute Error (same units as series)
            RMSE  — Root Mean Squared Error
            MAPE  — Mean Absolute Percentage Error (%, avoid near-zero actuals)
            MBE   — Mean Bias Error (signed; positive = systematic over-forecast)

        Args:
            actuals   (pd.Series): Observed values.
            forecasts (pd.Series): Model forecasts (must share same index).

        Returns:
            dict: {mae, rmse, mape, mbe}
        """
        errors = actuals - forecasts
        mae  = errors.abs().mean()
        rmse = np.sqrt((errors ** 2).mean())
        mbe  = errors.mean()

        # MAPE: only compute where actuals != 0
        nonzero = actuals != 0
        mape = (errors[nonzero].abs() / actuals[nonzero].abs()).mean() * 100

        metrics = dict(mae=mae, rmse=rmse, mape=mape, mbe=mbe)

        print("[QuantFilters] Forecast Accuracy:")
        for k, v in metrics.items():
            print(f"  {k.upper():>5}: {v:.6f}")

        return metrics