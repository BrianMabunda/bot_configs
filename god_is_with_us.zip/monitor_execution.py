import pandas as pd
import numpy as np

class ExecutionMonitor:
    @staticmethod
    def outlier_filter_moving_median(series, span=3):
        """
        Runs a Moving Median filter of span 3 to eliminate 'fat-finger'
        spikes of exactly u=1 observation before passing to the execution engine.
        """
        return series.rolling(window=span, center=True).median().fillna(series)

    @staticmethod
    def calculate_shewhart_limits(errors):
        """
        Calculates Upper and Lower Control Limits (UCL, LCL) based on
        Moving Range (MR) standard deviation estimation.
        """
        mean_error = errors.mean()
        moving_range = errors.diff().abs()
        avg_mr = moving_range.mean()
        
        # sigma = Avg(MR) / d2 (d2 for n=2 is 1.128)
        sigma_est = avg_mr / 1.128
        
        ucl = mean_error + (3 * sigma_est)
        lcl = mean_error - (3 * sigma_est)
        
        return ucl, lcl, moving_range

    @staticmethod
    def calculate_cusum(errors, threshold_multiplier=5):
        """
        Calculates the Cumulative Sum of errors with a RESET condition.
        If CUSUM breaches threshold, it flags for recalibration and resets to 0.

        Returns
        -------
        cusum_series, flag_series, threshold
            threshold is float(std(errors) * threshold_multiplier).
        """
        mean_error = errors.mean()
        sigma = errors.std()
        threshold = sigma * threshold_multiplier
        
        cusum_values = np.zeros(len(errors))
        deterioration_flags = np.zeros(len(errors), dtype=bool)
        running_sum = 0.0
        
        # We must iterate to track the running sum and reset it when it breaches
        for i in range(len(errors)):
            # Add the current centered error to the running sum
            running_sum += (errors.iloc[i] - mean_error)
            cusum_values[i] = running_sum
            
            # Check if it breached the threshold
            if abs(running_sum) > threshold:
                deterioration_flags[i] = True
                running_sum = 0.0  # RESET THE CUSUM TO ZERO
                
        # Convert back to Pandas Series to keep the date/time index
        cusum_series = pd.Series(cusum_values, index=errors.index)
        flag_series = pd.Series(deterioration_flags, index=errors.index)

        return cusum_series, flag_series, float(threshold)