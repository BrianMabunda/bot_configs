"""
MetaTrader 5 startup: attach to the terminal and optionally log in via credentials.

Never put real passwords in source code. Use either:
  - Environment variables: MT5_LOGIN, MT5_PASSWORD, MT5_SERVER
  - A local .env file (listed in .gitignore) loaded automatically if present

If credentials are omitted, the already-logged-in account in the MT5 terminal is used.
"""
import os

import MetaTrader5 as mt5


def _load_dotenv(path: str = ".env") -> None:
    """Minimal KEY=VALUE loader; does not override existing os.environ."""
    if not os.path.isfile(path):
        return
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" not in line:
                continue
            key, _, val = line.partition("=")
            key = key.strip()
            val = val.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = val


def init_mt5(load_env_file: bool = True) -> bool:
    """
    Initialize the MT5 terminal. If MT5_LOGIN, MT5_PASSWORD, and MT5_SERVER
    are set, call mt5.login() for that account.
    """
    if load_env_file:
        _load_dotenv()

    if not mt5.initialize():
        print("[MT5] initialize() failed — is MetaTrader 5 running?")
        return False

    login = os.environ.get("MT5_LOGIN")
    password = os.environ.get("MT5_PASSWORD")
    server = os.environ.get("MT5_SERVER")

    if not (login and password and server):
        print("[MT5] No MT5_LOGIN/MT5_PASSWORD/MT5_SERVER — using terminal session.")
        return True

    ok = mt5.login(int(login), password=password, server=server)
    if not ok:
        err = mt5.last_error()
        print(f"[MT5] login() failed: {err}")
        return False

    print(f"[MT5] Logged in to server {server} as {login}")
    return True


def shutdown_mt5() -> None:
    mt5.shutdown()
