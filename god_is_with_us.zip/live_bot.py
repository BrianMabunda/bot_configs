"""
live_bot.py — Multi-pair H1 AR live trading bot
=================================================
Trades multiple symbols simultaneously, each with its own:
  - AR model state
  - CUSUM error history
  - Last forecast
  - Position check

All symbols share the same daily loss cap, enforced at the account level.

BEFORE RUNNING
--------------
1. config.json: set symbols list, risk params.
2. MT5 terminal open and logged in.
3. Run on DEMO for 1 week minimum per symbol before live.
4. max_loss_per_trade_usd must be <= 6 for a 3-symbol $30 DD challenge.
"""
from __future__ import annotations

import time
import traceback
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List, Optional

import MetaTrader5 as mt5
import numpy as np
import pandas as pd

from ar_modeler import ARModeler
from data_engine import DataEngine
from monitor_execution import ExecutionMonitor
from risk_sizing import load_trading_config, risk_budget_usd, volume_for_risk
from trade_executor import TradeExecutor
from mt5_session import init_mt5

# ==============================================================================
#  PER-INSTRUMENT CONFIG
# ==============================================================================

INSTRUMENT_CONFIGS: Dict[str, dict] = {
    "GER40":  {"atr_edge_multiplier": 0.15,  "cusum_threshold_mult": 4, "cusum_min_history": 30, "magic": 888001},
    "NAS100": {"atr_edge_multiplier": 0.10,  "cusum_threshold_mult": 5, "cusum_min_history": 30, "magic": 888002},
    "XAUUSD": {"atr_edge_multiplier": 0.15,  "cusum_threshold_mult": 4, "cusum_min_history": 30, "magic": 888003},
    "GBPJPY": {"atr_edge_multiplier": 0.15,  "cusum_threshold_mult": 4, "cusum_min_history": 30, "magic": 888004},
    "EURUSD": {"atr_edge_multiplier": 0.15,  "cusum_threshold_mult": 4, "cusum_min_history": 30, "magic": 888005},
    "USDJPY": {"atr_edge_multiplier": 0.15,  "cusum_threshold_mult": 4, "cusum_min_history": 30, "magic": 888006},
}

_DEFAULT_CFG = {
    "atr_edge_multiplier": 0.15,
    "cusum_threshold_mult": 4,
    "cusum_min_history": 30,
    "magic": 999999,
}

TIMEFRAME     = mt5.TIMEFRAME_H1
REQUIRED_BARS = 6000
PRETRAIN_BARS = 1500
LOG_WINDOW    = 500
MAX_LAGS      = 8
if not mt5.initialize():
    print("initialize() failed, error code =", mt5.last_error())
    quit()


# ==============================================================================
#  PER-SYMBOL STATE
# ==============================================================================

@dataclass
class SymbolState:
    symbol:        str
    arm:           Optional[ARModeler] = None
    pretrained:    bool                = False
    last_forecast: Optional[float]     = None
    error_history: List[float]         = field(default_factory=list)

    def cfg(self) -> dict:
        return {**_DEFAULT_CFG, **INSTRUMENT_CONFIGS.get(self.symbol.upper(), {})}


# ==============================================================================
#  HELPERS
# ==============================================================================

def _calculate_atr(df: pd.DataFrame, period: int = 14) -> float:
    high       = df["high"].astype(float)
    low        = df["low"].astype(float)
    close      = df["close"].astype(float)
    prev_close = close.shift(1)
    tr = pd.concat(
        [high - low, (high - prev_close).abs(), (low - prev_close).abs()], axis=1
    ).max(axis=1)
    return float(tr.ewm(alpha=1.0 / period, adjust=False).mean().iloc[-1])


def _open_position_exists(symbol: str, magic: int) -> bool:
    positions = mt5.positions_get(symbol=symbol)
    if positions is None:
        return False
    return any(p.magic == magic for p in positions)


def _utc_naive(dt: datetime) -> datetime:
    """
    Strip timezone info so MT5 API functions receive a naive UTC datetime.

    ROOT CAUSE OF THE CRASH
    -----------------------
    mt5.history_select() and mt5.history_deals_get() require naive datetime
    objects (no tzinfo). Passing a timezone-aware datetime (tzinfo=UTC) raises:

        TypeError inside mt5.history_select — invalid argument type

    The fix: always call .replace(tzinfo=None) before any MT5 history call.
    This does NOT change the time value — it only removes the annotation.
    """
    return dt.replace(tzinfo=None)


def _account_pnl_today_usd(magics: List[int]) -> float:
    """
    Total P&L today (closed deals + open floating) across all magic numbers.
    Used to enforce the account-level daily loss cap.
    """
    now       = datetime.now(timezone.utc)
    day_start = now.replace(hour=0, minute=0, second=0, microsecond=0)

    # Convert to naive UTC before passing to MT5
    now_naive       = _utc_naive(now)
    day_start_naive = _utc_naive(day_start)

    closed_pnl = 0.0
    
    # FIX: Removed the non-existent mt5.history_select()
    # mt5.history_deals_get handles the selection and retrieval directly.
    deals = mt5.history_deals_get(day_start_naive, now_naive)
    
    if deals is not None and len(deals) > 0:
        for d in deals:
            if d.magic in magics:
                closed_pnl += float(d.profit) + float(d.swap) + float(d.commission)

    floating_pnl = 0.0
    all_pos = mt5.positions_get()
    if all_pos:
        for p in all_pos:
            if p.magic in magics:
                floating_pnl += float(p.profit)

    return closed_pnl + floating_pnl

def _validate_config(cfg: dict, symbols: List[str]) -> bool:
    r      = cfg.get("risk", {})
    per_t  = float(r.get("max_loss_per_trade_usd", 0))
    daily  = float(r.get("max_daily_loss_usd", 0))
    n_sym  = len(symbols)
    ok     = True

    worst_case = per_t * n_sym
    if worst_case > daily:
        print(
            f"[CONFIG WARNING] {n_sym} symbols × ${per_t:.0f}/trade = "
            f"${worst_case:.0f} worst-case loss per cycle.\n"
            f"  This exceeds your daily cap of ${daily:.0f}.\n"
            f"  Reduce max_loss_per_trade_usd to ${daily / n_sym:.1f} or less."
        )
        ok = False

    if per_t > 8:
        print(
            f"[CONFIG WARNING] max_loss_per_trade_usd=${per_t:.0f} is too high "
            f"for a $30 total DD challenge. Recommended: $5-6 per trade."
        )
        ok = False

    unvalidated = [s for s in symbols if s.upper() not in ("GER40", "NAS100")]
    if unvalidated:
        print(
            f"[CONFIG NOTE] These symbols have not been backtested: {unvalidated}.\n"
            f"  Run a backtest sweep before trading them live."
        )

    return ok


# ==============================================================================
#  PIPELINE
# ==============================================================================

def pretrain(state: SymbolState, train_df: pd.DataFrame) -> None:
    state.arm  = ARModeler(max_lags=MAX_LAGS)
    log_prices = np.log(train_df["close"])
    win        = min(LOG_WINDOW, max(50, len(log_prices) - 1))
    stationary = log_prices.iloc[-win:].diff().dropna()
    if len(stationary) < state.arm.max_lags + 2:
        state.arm.fit_ar_model(stationary, refit_lags=True)
    else:
        state.arm.select_optimal_lags(stationary, criterion="aic")
    print(f"[{state.symbol}] Pretrain: AR(p={state.arm.optimal_lags}) "
          f"on {len(train_df)} H1 bars.")
    state.pretrained = True


def run_pipeline(state: SymbolState, df: pd.DataFrame):
    if state.arm is None:
        raise RuntimeError(f"{state.symbol}: AR not initialised.")
    log_prices     = np.log(df["close"])
    stationary     = log_prices.iloc[-LOG_WINDOW:].diff().dropna()
    state.arm.fit_ar_model(stationary, refit_lags=False)
    fc_log         = state.arm.predict_next()
    sigma_sq       = state.arm.residual_variance
    last_log       = float(log_prices.iloc[-1])
    forecast_price = float(np.exp(last_log + fc_log + 0.5 * sigma_sq))
    atr            = _calculate_atr(df, period=14)
    return forecast_price, atr, float(sigma_sq)


# ==============================================================================
#  TRADING CYCLE (per symbol)
# ==============================================================================

def run_symbol_cycle(
    state:     SymbolState,
    cfg:       dict,
    daily_pnl: float,
    daily_cap: float,
) -> None:
    sym     = state.symbol
    sym_cfg = state.cfg()
    atr_m   = sym_cfg["atr_edge_multiplier"]
    c_mult  = sym_cfg["cusum_threshold_mult"]
    c_hist  = sym_cfg["cusum_min_history"]
    magic   = sym_cfg["magic"]

    # ── Fetch ──────────────────────────────────────────────────────────────────
    engine = DataEngine(symbol=sym, timeframe=TIMEFRAME, required_bars=REQUIRED_BARS)
    try:
        raw_df = engine.fetch_data()
    except Exception as e:
        print(f"[{sym}] Fetch error: {e}")
        return

    df = engine.stochastic_imputation(raw_df, reindex_freq=None)

    if len(df) < PRETRAIN_BARS + 50:
        print(f"[{sym}] Not enough bars ({len(df)}). Skipping.")
        return

    # ── Pre-train once ─────────────────────────────────────────────────────────
    if not state.pretrained:
        pretrain(state, df.iloc[:PRETRAIN_BARS])

    current_close = float(df["close"].iloc[-1])

    # ── CUSUM error update ─────────────────────────────────────────────────────
    if state.last_forecast is not None:
        state.error_history.append(current_close - state.last_forecast)
        if len(state.error_history) > 200:
            state.error_history.pop(0)

    # ── Pipeline ───────────────────────────────────────────────────────────────
    try:
        forecast_price, atr, sigma_sq = run_pipeline(state, df)
    except Exception as e:
        print(f"[{sym}] Pipeline error: {e}")
        traceback.print_exc()
        return

    state.last_forecast = forecast_price
    sigma_price         = current_close * float(np.sqrt(max(sigma_sq, 1e-12)))
    rb                  = risk_budget_usd(cfg)

    edge = abs(forecast_price - current_close)
    thr  = atr * atr_m
    print(
        f"[{sym}] Close={current_close:.5f} | FC={forecast_price:.5f} | "
        f"edge={edge:.5f} | thr={thr:.5f} (ATR×{atr_m})"
    )

    # ── Edge filter ────────────────────────────────────────────────────────────
    if edge < thr:
        print(f"[{sym}] No edge — skip.")
        return

    # ── CUSUM ──────────────────────────────────────────────────────────────────
    if len(state.error_history) >= c_hist:
        _, flags, _ = ExecutionMonitor.calculate_cusum(
            pd.Series(state.error_history), threshold_multiplier=c_mult
        )
        if flags.iloc[-1]:
            print(f"[{sym}] CUSUM breach — skip.")
            return
    else:
        print(f"[{sym}] Building CUSUM ({len(state.error_history)}/{c_hist}).")

    # ── Already in a position? ─────────────────────────────────────────────────
    if _open_position_exists(sym, magic):
        print(f"[{sym}] Position already open — skip.")
        return

    # ── Daily cap ──────────────────────────────────────────────────────────────
    remaining = daily_cap + daily_pnl      # daily_pnl is negative when losing
    if remaining <= 0:
        print(f"[{sym}] Daily cap exhausted (P&L=${daily_pnl:+.2f}) — skip.")
        return

    effective_rb = min(rb, remaining)
    if effective_rb < rb:
        print(f"[{sym}] Capping risk to ${effective_rb:.2f} (daily budget low).")

    # ── Tick ───────────────────────────────────────────────────────────────────
    tick = mt5.symbol_info_tick(sym)
    if tick is None:
        print(f"[{sym}] No tick — skip.")
        return

    # ── Direction + SL ────────────────────────────────────────────────────────
    if forecast_price > current_close:
        order_type = mt5.ORDER_TYPE_BUY
        entry      = float(tick.ask)
        sl         = entry - sigma_price * 1.5
    else:
        order_type = mt5.ORDER_TYPE_SELL
        entry      = float(tick.bid)
        sl         = entry + sigma_price * 1.5

    # ── Volume ─────────────────────────────────────────────────────────────────
    vol, vmsg = volume_for_risk(sym, order_type, entry, sl, effective_rb)
    print(f"[{sym}] Sizing: {vmsg}")
    if vol <= 0:
        print(f"[{sym}] Volume zero — abort.")
        return

    # SL loss sanity check
    info = mt5.symbol_info(sym)
    if info:
        est_loss = abs(entry - sl) * vol * (1.0 / info.point) * info.trade_tick_value
        print(f"[{sym}] Est SL loss=${est_loss:.2f} | day remaining=${remaining:.2f}")
        if est_loss > remaining * 1.05:
            print(f"[{sym}] Est loss exceeds day budget — abort.")
            return

    # ── Execute ────────────────────────────────────────────────────────────────
    executor = TradeExecutor(symbol=sym, magic=magic)
    result   = executor.execute_signal(current_close, forecast_price, sigma_price, volume=vol)
    if result is not None:
        direction = "BUY" if order_type == mt5.ORDER_TYPE_BUY else "SELL"
        print(f"[{sym}] ✓ {direction} {vol} lots @ {entry:.5f} | SL={sl:.5f}")


# ==============================================================================
#  MAIN LOOP
# ==============================================================================

def main() -> None:
    cfg       = load_trading_config()
    r         = cfg["risk"]
    ref_eq    = float(cfg["account"]["reference_equity_usd"])
    daily_cap = float(r["max_daily_loss_usd"])

    raw_syms = cfg["bot"].get("symbols", cfg["bot"].get("symbol", "GER40"))
    symbols  = [raw_syms] if isinstance(raw_syms, str) else list(raw_syms)
    all_magics = [
        INSTRUMENT_CONFIGS.get(s.upper(), _DEFAULT_CFG)["magic"]
        for s in symbols
    ]

    print(f"\n{'='*60}")
    print(f"[Bot] Multi-pair H1 | symbols={symbols}")
    print(f"      Equity=${ref_eq} | daily cap=${daily_cap}")
    print(f"      Risk/trade: {r['risk_per_trade_percent_of_equity']}% "
          f"(max ${r['max_loss_per_trade_usd']})")
    print(f"      Worst-case simultaneous loss: "
          f"${float(r['max_loss_per_trade_usd']) * len(symbols):.0f}")
    for s in symbols:
        sc = {**_DEFAULT_CFG, **INSTRUMENT_CONFIGS.get(s.upper(), {})}
        print(f"      {s}: atr_mult={sc['atr_edge_multiplier']} | "
              f"cusum_thr={sc['cusum_threshold_mult']} | magic={sc['magic']}")
    print(f"{'='*60}\n")

    if not _validate_config(cfg, symbols):
        print(
            "[Bot] Fix config.json risk settings before running live.\n"
            "      Recommended for 3-symbol $30 DD challenge:\n"
            '        "risk_per_trade_percent_of_equity": 0.5\n'
            '        "max_loss_per_trade_usd": 6\n'
            '        "max_daily_loss_usd": 20\n'
            "[Bot] Exiting."
        )
        return

    states: Dict[str, SymbolState] = {s: SymbolState(symbol=s) for s in symbols}
    last_bar_time: Optional[int]   = None

    while True:
        if not mt5.terminal_info():
            print("[Bot] MT5 disconnected. Waiting 5s...")
            time.sleep(5)
            continue

        rates = mt5.copy_rates_from_pos(symbols[0], TIMEFRAME, 0, 2)
        if rates is None or len(rates) < 1:
            time.sleep(1)
            continue

        bar_time = int(rates[-1]["time"])

        if last_bar_time is None:
            last_bar_time = bar_time
            time.sleep(1)
            continue

        if bar_time > last_bar_time:
            print(f"\n{'─'*60}")
            print(f"[Bot] New H1 bar: {datetime.fromtimestamp(bar_time)}")
            print(f"{'─'*60}")

            # Single account-level P&L check — shared by all symbols this bar
            daily_pnl = _account_pnl_today_usd(all_magics)
            print(f"[Bot] Account P&L today: ${daily_pnl:+.2f} | "
                  f"remaining=${daily_cap + daily_pnl:.2f}")

            for sym, state in states.items():
                print(f"\n── {sym} ──")
                try:
                    run_symbol_cycle(state, cfg, daily_pnl, daily_cap)
                except Exception as e:
                    print(f"[{sym}] Unhandled error: {e}")
                    traceback.print_exc()

            last_bar_time = bar_time

        time.sleep(1)


if __name__ == "__main__":
    if init_mt5():
        try:
            main()
        finally:
            mt5.shutdown()
    else:
        print("[Bot] MT5 initialization failed — is MetaTrader 5 open?")