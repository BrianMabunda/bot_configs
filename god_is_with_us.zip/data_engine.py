import MetaTrader5 as mt5
import numpy as np
import pandas as pd

# Map MT5 timeframe constants to pandas offset strings for optional calendar reindex.
_TIMEFRAME_TO_FREQ = {
    mt5.TIMEFRAME_M1: "1min",
    mt5.TIMEFRAME_M5: "5min",
    mt5.TIMEFRAME_M15: "15min",
    mt5.TIMEFRAME_M30: "30min",
    mt5.TIMEFRAME_H1: "1h",
    mt5.TIMEFRAME_H4: "4h",
    mt5.TIMEFRAME_D1: "1D",
}


def infer_pandas_freq(timeframe):
    """Return pandas frequency string for a MT5 timeframe, or None if unknown."""
    return _TIMEFRAME_TO_FREQ.get(timeframe)


class DataEngine:
    def __init__(self, symbol="GBPJPY", timeframe=mt5.TIMEFRAME_H1, required_bars=99999):
        self.symbol = symbol
        self.timeframe = timeframe
        self.required_bars = required_bars

    def fetch_data(self):
        """Fetches bars from MT5."""
        if not mt5.initialize():
            raise ConnectionError("MT5 initialization failed")

        rates = mt5.copy_rates_from_pos(self.symbol, self.timeframe, 0, self.required_bars)

        if rates is None or len(rates) == 0:
            raise ValueError("Failed to fetch data from MT5")

        df = pd.DataFrame(rates)
        df["time"] = pd.to_datetime(df["time"], unit="s")
        df.set_index("time", inplace=True)
        return df

    def fetch_data_range(self, date_from, date_to):
        """
        Fetch bars between date_from and date_to (UTC, timezone-aware or naive).
        Uses mt5.copy_rates_range.
        """
        if not mt5.initialize():
            raise ConnectionError("MT5 initialization failed")

        if isinstance(date_from, pd.Timestamp):
            date_from = date_from.to_pydatetime()
        if isinstance(date_to, pd.Timestamp):
            date_to = date_to.to_pydatetime()

        rates = mt5.copy_rates_range(self.symbol, self.timeframe, date_from, date_to)
        if rates is None or len(rates) == 0:
            raise ValueError(
                f"No rates for {self.symbol} between {date_from} and {date_to}"
            )

        df = pd.DataFrame(rates)
        df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
        df.set_index("time", inplace=True)
        return df

    def apply_13_month_calendar(self, df):
        """
        Maps standard dates into a 13-month, 28-day (4-week) consistency protocol.
        Prevents seasonal noise caused by varying days in standard calendar months.
        """
        day_of_year = df.index.dayofyear
        df["standard_month"] = (day_of_year // 28) + 1
        df["standard_day"] = (day_of_year % 28) + 1

        # Clip the 365th day (or 366th) to the 13th month to maintain consistency
        df.loc[df["standard_month"] > 13, "standard_month"] = 13
        return df

    def stochastic_imputation(self, df, reindex_freq=None):
        """
        Fills small gaps in OHLC series.

        Parameters
        ----------
        reindex_freq : str or None
            None (recommended for spot FX M15/M5): do **not** expand to a full
            calendar grid. Keeps MT5 bar index as-is (avoids inventing weekend/holiday
            bars). Only forward-fills up to 2 consecutive missing **rows** and
            stochastically imputes any remaining NaNs.

            '15min', '1h', etc.: legacy behaviour — build a dense time grid from
            first to last timestamp (can create many NaNs over weekends; use for
            aligned research backtests when that is intended).
        """
        df = df.sort_index()
        if reindex_freq is None:
            out = df.copy()
            if out["close"].isna().any():
                out = out.ffill(limit=2)
                still_missing = out["close"].isna()
                if still_missing.any():
                    global_mean = df["close"].mean()
                    global_std = df["close"].std()
                    if global_std is None or (isinstance(global_std, float) and np.isnan(global_std)):
                        global_std = 0.0
                    noise = np.random.normal(0, global_std, size=still_missing.sum())
                    out.loc[still_missing, "close"] = global_mean + noise
            return out

        full_index = pd.date_range(start=df.index.min(), end=df.index.max(), freq=reindex_freq)
        df_reindexed = df.reindex(full_index)

        missing_mask = df_reindexed["close"].isna()

        if not missing_mask.any():
            return df_reindexed

        # Hot Deck: forward fill up to 2 consecutive missing bars
        df_reindexed = df_reindexed.ffill(limit=2)

        still_missing = df_reindexed["close"].isna()
        if still_missing.any():
            global_mean = df["close"].mean()
            global_std = df["close"].std()
            noise = np.random.normal(0, global_std, size=still_missing.sum())
            df_reindexed.loc[still_missing, "close"] = global_mean + noise

        return df_reindexed
