import warnings
import numpy as np
import pandas as pd
from statsmodels.tsa.ar_model import AutoReg

# Suppress the flood of statsmodels ValueWarnings caused by freq-less
# DatetimeIndex (MT5 FX bars skip weekends so pandas cannot infer a freq).
# The _to_range_index() helper below is the structural fix; this suppressor
# is a belt-and-suspenders safety net for any call path that bypasses it.
warnings.filterwarnings(
    "ignore",
    message=".*date index.*frequency.*",
    category=UserWarning,
    module="statsmodels",
)
warnings.filterwarnings(
    "ignore",
    message=".*No supported index.*",
    category=UserWarning,
    module="statsmodels",
)


def _to_range_index(series: pd.Series) -> pd.Series:
    """
    Strip any DatetimeIndex and replace with a plain RangeIndex before
    passing to statsmodels AutoReg.

    ROOT CAUSE OF THE CRASH
    -----------------------
    MT5 returns FX bars with a DatetimeIndex that has NO associated frequency
    (weekends / holidays are absent, so pandas cannot infer a regular freq).
    When AutoReg receives this index it:
      1. Emits hundreds of ValueWarnings about the missing freq, AND
      2. Crashes inside AutoRegResultsWrapper.resid -> fittedvalues ->
         predict -> _prepare_prediction -> array_like because the internal
         prediction-index arithmetic cannot handle a freq-less DatetimeIndex.

    The fix: reset to RangeIndex before every AutoReg() call.
    Zero effect on model fit or forecasts — AutoReg only needs the numbers.
    """
    if not isinstance(series.index, pd.RangeIndex):
        return series.reset_index(drop=True)
    return series


class ARModeler:
    def __init__(self, max_lags=20):
        """
        Args:
            max_lags: Upper bound for AIC/BIC lag search. Default 20 for M15 data.

        NOTE: The constructor parameter is `max_lags`, NOT `lags`.
        ARModeler(lags=1) will raise a TypeError — always use ARModeler(max_lags=20).
        The optimal p is selected automatically by AIC inside fit_ar_least_squares().
        """
        self.max_lags          = max_lags
        self.optimal_lags      = None
        self.model_fit         = None
        self.residual_variance = None
        self._lag_scores       = {}

    # ------------------------------------------------------------------ #
    #  1. OPTIMAL LAG SELECTION                                            #
    # ------------------------------------------------------------------ #
    def select_optimal_lags(self, stationary_series, criterion='aic'):
        """
        Selects the optimal AR lag order via AIC or BIC information criteria.

        Args:
            stationary_series: Differenced, stationary residual series.
            criterion: 'aic' (default) or 'bic'.

        Returns:
            int: Optimal lag order p*.
        """
        s = _to_range_index(stationary_series)

        best_score = np.inf
        best_lag   = 1

        for lag in range(1, self.max_lags + 1):
            try:
                fit   = AutoReg(s, lags=lag).fit()
                score = fit.aic if criterion == 'aic' else fit.bic
                self._lag_scores[lag] = score
                if score < best_score:
                    best_score = score
                    best_lag   = lag
            except Exception:
                continue

        self.optimal_lags = best_lag
        print(f"[ARModeler] Optimal lags: p={best_lag} "
              f"({criterion.upper()}={best_score:.4f})")
        return best_lag

    # ------------------------------------------------------------------ #
    #  2. LEAST SQUARES AR FIT                                            #
    # ------------------------------------------------------------------ #
    def fit_ar_least_squares(self, stationary_series, criterion='aic'):
        """
        Selects optimal p via AIC/BIC, then fits AR(p) to stationary residuals.
        Stores residual variance for log-bias correction downstream.

        Args:
            stationary_series: Stationary residual series post-differencing.
            criterion: Information criterion for lag selection.

        Returns:
            AutoRegResultsWrapper: Fitted model object.
        """
        s = _to_range_index(stationary_series)

        if self.optimal_lags is None:
            self.select_optimal_lags(s, criterion=criterion)

        model          = AutoReg(s, lags=self.optimal_lags)
        self.model_fit = model.fit()
        self.residual_variance = float(np.var(self.model_fit.resid))

        print(f"[ARModeler] AR({self.optimal_lags}) fitted. "
              f"sigma^2={self.residual_variance:.2e}")
        return self.model_fit

    # ------------------------------------------------------------------ #
    #  3. WALK-FORWARD FIT (used by backtest + live_bot)                  #
    # ------------------------------------------------------------------ #
    def fit_ar_model(self, stationary_series, criterion="aic", refit_lags=False):
        """
        Fit AR(p) on a log-return (or other stationary) series for one-step
        prediction. Used by backtest.py walk-forward loop. By default lag
        order is chosen once per ARModeler instance; set refit_lags=True to
        re-run AIC each call (slow).
        """
        s = _to_range_index(stationary_series)

        if self.optimal_lags is None or refit_lags:
            self.optimal_lags = None
            self.select_optimal_lags(s, criterion=criterion)

        model = AutoReg(s, lags=self.optimal_lags)
        self.model_fit = model.fit()
        self.residual_variance = float(np.var(self.model_fit.resid))
        return self.model_fit

    # ------------------------------------------------------------------ #
    #  4. ONE-STEP-AHEAD FORECAST                                         #
    # ------------------------------------------------------------------ #
    def predict_next(self, stationary_series=None):
        """
        One-step-ahead forecast from the last fitted AR model.
        stationary_series is optional; kept for API compatibility.
        """
        if self.model_fit is None:
            raise RuntimeError("Call fit_ar_model before predict_next.")
        fc = self.model_fit.forecast(steps=1)
        return float(np.asarray(fc).ravel()[0])

    # ------------------------------------------------------------------ #
    #  5. TRIGG-LEACH ADAPTIVE FORECAST                                   #
    # ------------------------------------------------------------------ #
    def trigg_leach_adaptive_forecast(self, actuals, initial_forecasts,
                                       base_alpha=0.2):
        """
        Applies Trigg-Leach Adaptive Discount Factor.
        Alpha updates dynamically from the Tracking Signal.

        Can be applied to:
          - Log prices directly  (PATH B -> back-transform: exp(fc + 0.5*sigma^2))
          - Stationary residuals (PATH A -> back-transform: back_transform())

        IMPORTANT: Always returns a TUPLE of two pd.Series.
            forecasts, alpha_history = arm.trigg_leach_adaptive_forecast(...)
        Do NOT unpack as a single value.

        Args:
            actuals (pd.Series): Observed values.
            initial_forecasts (array-like): Seed forecast values.
            base_alpha (float): Starting smoothing constant in (0,1).

        Returns:
            Tuple[pd.Series, pd.Series]:
                forecasts     - Lead-1 adaptive forecasts.
                alpha_history - Time series of adaptive alpha values.
        """
        n                  = len(actuals)
        forecasts          = np.zeros(n)
        alpha_history      = np.zeros(n)
        smoothed_error     = 0.0
        smoothed_abs_error = 1e-9
        alpha              = base_alpha

        forecasts[0]     = (initial_forecasts[0]
                            if len(initial_forecasts) > 0
                            else actuals.iloc[0])
        alpha_history[0] = alpha

        for t in range(1, n):
            e_t                = actuals.iloc[t] - forecasts[t - 1]
            smoothed_error     = alpha * e_t      + (1 - alpha) * smoothed_error
            smoothed_abs_error = alpha * abs(e_t) + (1 - alpha) * smoothed_abs_error
            ts                 = smoothed_error / smoothed_abs_error
            alpha              = max(0.01, min(0.99, abs(ts)))
            forecasts[t]       = forecasts[t - 1] + (alpha * e_t)
            alpha_history[t]   = alpha

        return (
            pd.Series(forecasts,     index=actuals.index, name='tl_forecast'),
            pd.Series(alpha_history, index=actuals.index, name='alpha'),
        )

    # ------------------------------------------------------------------ #
    #  6. BACK-TRANSFORMATION - PATH A ONLY                               #
    # ------------------------------------------------------------------ #
    @staticmethod
    def back_transform(forecast_log_diff, last_known_log_price,
                       seasonal_additions, sigma_squared=0.0):
        """
        Reverses differencing and log-transform for PATH A (AR on stationary).
        Applies Jensen's Inequality bias correction (+0.5*sigma^2) in log-space.

        Formula:
            log(y_hat_t) = log(y_{t-1}) + seasonal_additions
                           + forecast_diff + 0.5*sigma^2
            y_hat_t      = exp(log(y_hat_t))

        DO NOT use for PATH B (Trigg-Leach on log prices).
        For PATH B: price_forecast = exp(tl_log_fc + 0.5*sigma^2)

        Args:
            forecast_log_diff:    AR model forecast in differenced log-space.
            last_known_log_price: log(y_{t-1}).
            seasonal_additions:   Winters seasonal component S_t.
            sigma_squared:        Residual variance (arm.residual_variance).

        Returns:
            np.ndarray: Back-transformed price forecast in original units.
        """
        log_forecast = (last_known_log_price
                        + seasonal_additions
                        + forecast_log_diff
                        + 0.5 * sigma_squared)
        return np.exp(log_forecast)