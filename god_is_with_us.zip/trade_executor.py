import MetaTrader5 as mt5
import pandas as pd
import numpy as np

class TradeExecutor:
    def __init__(self, symbol="EURUSD", magic=123456):
        self.symbol = symbol
        self.magic = magic
        self.deviation = 20 # Slippage tolerance in points

    def calculate_atr(self, df, period=14):
        """
        Wilder-style ATR from OHLC (same units as price). Requires columns
        high, low, close.
        """
        high = df["high"].astype(float)
        low = df["low"].astype(float)
        close = df["close"].astype(float)
        prev_close = close.shift(1)
        tr = pd.concat(
            [
                high - low,
                (high - prev_close).abs(),
                (low - prev_close).abs(),
            ],
            axis=1,
        ).max(axis=1)
        atr = tr.ewm(alpha=1.0 / period, adjust=False).mean()
        return float(atr.iloc[-1])

    def get_pip_unit(self):
        """Calculates the pip value based on symbol digits."""
        info = mt5.symbol_info(self.symbol)
        if info is None:
            return 0.0001
        return 10 ** -info.digits * (10 if info.digits in [3, 5] else 1)

    def execute_signal(self, current_price, forecast_price, sigma, volume=None):
        """
        Translates a price forecast into an MT5 order.
        Uses sigma to set SL distance (1.5 * sigma). TP at forecast.
        If volume is None, uses 0.1 lot (legacy default).
        """
        # 1. Determine Direction
        direction = mt5.ORDER_TYPE_BUY if forecast_price > current_price else mt5.ORDER_TYPE_SELL

        # 2. Calculate dynamic SL/TP based on 2-sigma (95% confidence)
        # We want the TP to be at the forecast and SL at 1.5x sigma distance
        risk_dist = sigma * 1.5

        if direction == mt5.ORDER_TYPE_BUY:
            price = mt5.symbol_info_tick(self.symbol).ask
            sl = price - risk_dist
            tp = forecast_price
        else:
            price = mt5.symbol_info_tick(self.symbol).bid
            sl = price + risk_dist
            tp = forecast_price

        info = mt5.symbol_info(self.symbol)
        digits = int(info.digits) if info is not None else 5
        lot = 0.1 if volume is None else float(volume)

        # 3. Build Request
        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": self.symbol,
            "volume": lot,
            "type": direction,
            "price": price,
            "sl": round(sl, digits),
            "tp": round(tp, digits),
            "deviation": self.deviation,
            "magic": self.magic,
            "comment": "Adaptive Seasonal Forecast",
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }

        # 4. Send Order
        result = mt5.order_send(request)
        if result.retcode != mt5.TRADE_RETCODE_DONE:
            print(f"Order failed: {result.comment} (Code: {result.retcode})")
            return None
            
        print(f"Order Executed: {self.symbol} {'BUY' if direction == 0 else 'SELL'} @ {price}")
        return result

    def close_all_positions(self):
        """Safety function to flatten all positions for this magic number."""
        positions = mt5.positions_get(symbol=self.symbol, magic=self.magic)
        if positions:
            for pos in positions:
                # Closing requires a reciprocal order
                trade_type = mt5.ORDER_TYPE_SELL if pos.type == mt5.ORDER_TYPE_BUY else mt5.ORDER_TYPE_BUY
                price = mt5.symbol_info_tick(self.symbol).bid if pos.type == mt5.ORDER_TYPE_BUY else mt5.symbol_info_tick(self.symbol).ask
                
                request = {
                    "action": mt5.TRADE_ACTION_DEAL,
                    "symbol": self.symbol,
                    "volume": pos.volume,
                    "type": trade_type,
                    "position": pos.ticket,
                    "price": price,
                    "deviation": self.deviation,
                    "magic": self.magic,
                    "type_time": mt5.ORDER_TIME_GTC,
                    "type_filling": mt5.ORDER_FILLING_IOC,
                }
                mt5.order_send(request)
            print(f"All positions closed for Magic {self.magic}")