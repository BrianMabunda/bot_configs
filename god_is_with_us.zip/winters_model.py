import numpy as np
import pandas as pd

class WintersAdditiveModel:
    """
    Winters' Additive Seasonal Smoothing Model (Proposal Section 8.1).

    Simultaneously and recursively updates three components:
        L_t  = Level (de-trended, de-seasonalised local mean)
        T_t  = Trend (local slope estimate)
        S_t  = Seasonal index for the current period within the cycle

    Lead-h forecast:
        F_{t+h} = (L_t + h * T_t) + S_{t+h-m}

    This is the MISSING PIECE in the current pipeline that is responsible
    for the oscillating CUSUM. Without Winters, the seasonal components
    are stripped by differencing but never properly added back during
    back-transformation — causing alternating over/under-prediction.

    Attributes:
        m (int): Season length in bars (e.g., 96 for M15 intraday cycle).
        alpha (float): Level smoothing constant ∈ (0,1).
        beta  (float): Trend smoothing constant ∈ (0,1).
        gamma (float): Seasonal smoothing constant ∈ (0,1).
    """

    def __init__(self, m=24, alpha=0.2, beta=0.1, gamma=0.1):
        self.m = m
        self.alpha = alpha
        self.beta  = beta
        self.gamma = gamma

        # State containers
        self.level_   = None
        self.trend_   = None
        self.seasonal_= None  # Array of length m, one index per period

    # ------------------------------------------------------------------ #
    #  INITIALISATION                                                      #
    # ------------------------------------------------------------------ #
    def _initialise(self, series):
        """
        Initialises Level, Trend, and Seasonal indices from the first
        2 * m observations using the classical decomposition approach.

        Args:
            series (pd.Series): Log-transformed price series.
        """
        if len(series) < 2 * self.m:
            raise ValueError(
                f"Series too short for initialisation. "
                f"Need >= {2*self.m} obs, got {len(series)}."
            )

        # Initial Level: mean of first season
        self.level_ = series.iloc[:self.m].mean()

        # Initial Trend: average difference between consecutive season means
        self.trend_ = (
            (series.iloc[self.m:2*self.m].mean() - series.iloc[:self.m].mean())
            / self.m
        )

        # Initial Seasonal indices: obs - level, normalised to zero-sum
        seasonal_raw = np.zeros(self.m)
        for i in range(self.m):
            seasonal_raw[i] = series.iloc[i] - self.level_

        # Centre so indices sum to zero (additive model constraint)
        self.seasonal_ = seasonal_raw - seasonal_raw.mean()

    # ------------------------------------------------------------------ #
    #  FIT AND GENERATE ONE-STEP-AHEAD FORECASTS                          #
    # ------------------------------------------------------------------ #
    def fit(self, series):
        """
        Fits the model to a log-transformed series and returns:
          - One-step-ahead forecasts (same index as series)
          - Extracted seasonal components per bar

        Args:
            series (pd.Series): Log-transformed close price.

        Returns:
            Tuple[pd.Series, pd.Series]:
                forecasts      — Lead-1 fitted values in log-space.
                seasonal_track — Seasonal index S_t for each bar (for
                                 use in back_transform's seasonal_additions).
        """
        self._initialise(series)

        n = len(series)
        forecasts       = np.zeros(n)
        seasonal_track  = np.zeros(n)
        seasonal_buf    = self.seasonal_.copy()   # Working copy of S indices

        L = self.level_
        T = self.trend_

        for t in range(n):
            s_idx = t % self.m   # Which position in the seasonal cycle

            # Lead-1 forecast using PREVIOUS state
            forecasts[t]      = L + T + seasonal_buf[s_idx]
            seasonal_track[t] = seasonal_buf[s_idx]

            # Observe actual and update state
            y_t = series.iloc[t]

            L_prev = L
            # Update Level
            L = self.alpha * (y_t - seasonal_buf[s_idx]) + (1 - self.alpha) * (L + T)
            # Update Trend
            T = self.beta  * (L - L_prev)              + (1 - self.beta)  * T
            # Update Seasonal index for this period
            seasonal_buf[s_idx] = (
                self.gamma * (y_t - L)
                + (1 - self.gamma) * seasonal_buf[s_idx]
            )

        # Save final state for rolling out-of-sample forecasting
        self.level_    = L
        self.trend_    = T
        self.seasonal_ = seasonal_buf

        return (
            pd.Series(forecasts,      index=series.index, name='winters_forecast'),
            pd.Series(seasonal_track, index=series.index, name='seasonal_component')
        )

    # ------------------------------------------------------------------ #
    #  ROLLING LEAD-h FORECAST (for live deployment)                      #
    # ------------------------------------------------------------------ #
    def forecast(self, h=1):
        """
        Generates lead-h forecasts from the current model state.
        Call this at the close of each M15 bar in live trading.

        Args:
            h (int): Forecast horizon (bars ahead). Default 1 for lead-1.

        Returns:
            np.ndarray: Array of h forecast values in log-space.
        """
        if self.level_ is None:
            raise RuntimeError("Model not fitted. Call fit() first.")

        preds = np.zeros(h)
        for step in range(1, h + 1):
            s_idx = step % self.m
            preds[step - 1] = self.level_ + step * self.trend_ + self.seasonal_[s_idx]
        return preds