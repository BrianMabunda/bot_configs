"""
Load trading_config from JSON and compute lot size from USD risk at stop distance.

Uses MetaTrader5 order_calc_profit (1.0 lot) to estimate loss to SL in account currency.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import MetaTrader5 as mt5


def _config_path() -> Path:
    base = Path(__file__).resolve().parent
    p = base / "config.json"
    if p.is_file():
        return p
    ex = base / "config.example.json"
    if ex.is_file():
        return ex
    raise FileNotFoundError("config.json or config.example.json not found")


def load_trading_config() -> Dict[str, Any]:
    with open(_config_path(), encoding="utf-8") as f:
        return json.load(f)


def _equity_usd(cfg: Dict[str, Any]) -> float:
    ref = float(cfg["account"]["reference_equity_usd"])
    if not cfg.get("risk", {}).get("use_mt5_equity_when_available", True):
        return ref
    ai = mt5.account_info()
    if ai is None:
        return ref
    eq = float(ai.equity)
    if eq > 0:
        return eq
    return ref


def risk_budget_usd(cfg: Dict[str, Any]) -> float:
    """
    Dollars willing to lose if SL is hit for the next trade.
    min(percent of equity, max_loss_per_trade_usd).
    """
    r = cfg["risk"]
    eq = _equity_usd(cfg)
    pct = float(r["risk_per_trade_percent_of_equity"])
    cap = float(r["max_loss_per_trade_usd"])
    return min(eq * (pct / 100.0), cap)


def daily_closed_pnl_usd(magic: int, symbol: Optional[str] = None) -> float:
    """
    Sum profit (account currency) from closed deals since UTC midnight today.
    Filters by magic; optionally by symbol. Requires history_select to succeed.
    """
    now = datetime.now(timezone.utc)
    day_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    if not mt5.history_select(day_start, now):
        return 0.0
    deals = mt5.history_deals_get(day_start, now)
    if deals is None:
        return 0.0
    total = 0.0
    for d in deals:
        if d.magic != magic:
            continue
        if symbol and d.symbol != symbol:
            continue
        total += float(d.profit) + float(d.swap) + float(d.commission)
    return total


def daily_loss_exceeded(cfg: Dict[str, Any], magic: int, symbol: str) -> Tuple[bool, float, float]:
    """
    Returns (exceeded, pnl_today, limit).
    Loss = negative pnl; exceeded if pnl_today <= -max_daily_loss_usd.
    """
    limit = float(cfg["risk"]["max_daily_loss_usd"])
    pnl = daily_closed_pnl_usd(magic, symbol)
    if pnl <= -limit:
        return True, pnl, limit
    return False, pnl, limit


def loss_per_lot_to_sl(
    symbol: str, order_type: int, entry_price: float, sl_price: float
) -> Optional[float]:
    """
    Estimated loss in account currency for 1.0 lot if SL fills at sl_price.
    """
    if not mt5.symbol_select(symbol, True):
        return None
    pnl = mt5.order_calc_profit(order_type, symbol, 1.0, entry_price, sl_price)
    if pnl is None:
        return None
    return abs(float(pnl))


def volume_for_risk(
    symbol: str,
    order_type: int,
    entry_price: float,
    sl_price: float,
    risk_usd: float,
) -> Tuple[float, str]:
    """
    Returns (volume, message). Clamps to broker min/max/step.
    """
    info = mt5.symbol_info(symbol)
    if info is None:
        return 0.0, "symbol_info is None"

    loss_1 = loss_per_lot_to_sl(symbol, order_type, entry_price, sl_price)
    if loss_1 is None or loss_1 < 1e-9:
        return info.volume_min, "order_calc_profit failed or zero loss/lot; using volume_min"

    raw = risk_usd / loss_1
    step = float(info.volume_step)
    vmin = float(info.volume_min)
    vmax = float(info.volume_max)
    raw = max(vmin, min(vmax, raw))
    n = round(raw / step)
    vol = max(vmin, min(vmax, n * step))
    msg = f"risk_usd={risk_usd:.2f} loss/lot={loss_1:.2f} -> volume={vol}"
    return vol, msg
